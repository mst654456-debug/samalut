package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.LocalPolice
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.ui.theme.EduBlue
import com.example.ui.theme.EduBlueDark
import com.example.ui.theme.EduGold
import com.example.ui.theme.EduGreen
import com.example.util.BiometricHelper

/**
 * شاشة الدخول بالبصمة فقط (بدون اسم مستخدم أو كلمة مرور).
 * - تطلب البصمة تلقائياً عند الفتح.
 * - إذا كان الجهاز بلا بصمة / قفل شاشة مفعّل يظهر زر دخول مباشر مع تنبيه حتى لا يُحبس المستخدم خارج التطبيق.
 */
@Composable
fun LoginScreen(
    onAuthenticated: () -> Unit
) {
    val context = LocalContext.current
    val biometricAvailable = remember { BiometricHelper.isAvailable(context) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    fun promptBiometric() {
        val activity = BiometricHelper.findActivity(context)
        if (activity == null) {
            errorMessage = "تعذر فتح نافذة البصمة على هذا الجهاز."
            return
        }
        errorMessage = null
        BiometricHelper.authenticate(
            activity = activity,
            title = "تسجيل الدخول",
            subtitle = "ضع إصبعك على مستشعر البصمة للدخول",
            onSuccess = onAuthenticated,
            onError = { msg -> errorMessage = msg }
        )
    }

    // طلب البصمة تلقائياً عند أول ظهور للشاشة
    LaunchedEffect(Unit) {
        if (biometricAvailable) promptBiometric()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(EduBlueDark, EduBlue, MaterialTheme.colorScheme.background)
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(Color.White.copy(alpha = 0.2f), CircleShape)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(EduGold, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "أيقونة أمن سمالوط",
                        tint = EduBlueDark,
                        modifier = Modifier.size(40.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "إدارة أمن الإدارة التعليمية بسمالوط",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Text(
                text = "المسؤول: مستر مصطفى فرغلي",
                style = MaterialTheme.typography.bodyMedium,
                color = EduGold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(28.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("login_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "الدخول بالبصمة",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )

                    Text(
                        text = "منظومة متابعة المدارس والأحداث الأمنية",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
                    )

                    if (errorMessage != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ErrorOutline,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = errorMessage.orEmpty(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                    }

                    if (biometricAvailable) {
                        Box(
                            modifier = Modifier
                                .size(96.dp)
                                .background(EduBlue.copy(alpha = 0.12f), CircleShape)
                                .clickable { promptBiometric() }
                                .testTag("biometric_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = "الدخول بالبصمة",
                                tint = EduBlue,
                                modifier = Modifier.size(60.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "اضغط على البصمة للدخول",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = EduBlue
                        )
                    } else {
                        Text(
                            text = BiometricHelper.unavailableReason(context),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = onAuthenticated,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("login_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EduGreen)
                        ) {
                            Text(
                                text = "دخول (بدون بصمة)",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Surface(
                color = Color.White.copy(alpha = 0.9f),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalPolice,
                        contentDescription = null,
                        tint = EduBlueDark,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "غرفة عمليات أمن إدارة سمالوط التعليمية",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = EduBlueDark
                        )
                        Text(
                            text = "متابعة مستمرة لمدارس المركز وتأمين الامتحانات والمنشآت",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF455A64)
                        )
                    }
                }
            }
        }
    }
}
