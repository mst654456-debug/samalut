package com.example.data.local

import androidx.room.*
import com.example.data.model.DailyLogEntry
import com.example.data.model.EventEntity
import com.example.data.model.IncidentStatus
import com.example.data.model.School
import com.example.data.model.SchoolEntity
import com.example.data.model.SchoolStage
import com.example.data.model.SecurityIncident
import com.example.data.model.Teacher
import kotlinx.coroutines.flow.Flow

@Dao
interface SchoolDao {
    @Query("SELECT * FROM schools ORDER BY name ASC")
    fun getAllSchools(): Flow<List<School>>

    @Query("SELECT * FROM schools WHERE stage = :stage ORDER BY name ASC")
    fun getSchoolsByStage(stage: SchoolStage): Flow<List<School>>

    @Query("SELECT * FROM schools WHERE id = :id LIMIT 1")
    suspend fun getSchoolById(id: Long): School?

    @Query("SELECT * FROM schools WHERE name = :name LIMIT 1")
    suspend fun getSchoolByName(name: String): School?

    @Query("SELECT * FROM schools WHERE code = :code LIMIT 1")
    suspend fun getSchoolByCode(code: String): School?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchool(school: School): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchools(schools: List<School>)

    @Update
    suspend fun updateSchool(school: School)

    @Delete
    suspend fun deleteSchool(school: School)

    @Query("DELETE FROM schools WHERE id = :id")
    suspend fun deleteSchoolById(id: Long)

    @Query("SELECT COUNT(*) FROM schools")
    suspend fun getCount(): Int

    @Query("DELETE FROM schools")
    suspend fun deleteAll()
}

@Dao
interface TeacherDao {
    @Query("SELECT * FROM teachers ORDER BY name ASC")
    fun getAllTeachers(): Flow<List<Teacher>>

    @Query("SELECT * FROM teachers WHERE schoolName = :schoolName ORDER BY name ASC")
    fun getTeachersBySchool(schoolName: String): Flow<List<Teacher>>

    @Query("SELECT * FROM teachers WHERE stage = :stage ORDER BY name ASC")
    fun getTeachersByStage(stage: SchoolStage): Flow<List<Teacher>>

    @Query("SELECT * FROM teachers WHERE id = :id LIMIT 1")
    suspend fun getTeacherById(id: Long): Teacher?

    @Query("SELECT * FROM teachers WHERE teacherCode = :code LIMIT 1")
    suspend fun getTeacherByCode(code: String): Teacher?

    @Query("SELECT * FROM teachers WHERE nationalId = :nationalId LIMIT 1")
    suspend fun getTeacherByNationalId(nationalId: String): Teacher?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeacher(teacher: Teacher): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeachers(teachers: List<Teacher>)

    @Update
    suspend fun updateTeacher(teacher: Teacher)

    @Delete
    suspend fun deleteTeacher(teacher: Teacher)

    @Query("DELETE FROM teachers WHERE id = :id")
    suspend fun deleteTeacherById(id: Long)

    @Query("SELECT COUNT(*) FROM teachers")
    suspend fun getCount(): Int

    @Query("DELETE FROM teachers")
    suspend fun deleteAll()
}

@Dao
interface SecurityIncidentDao {
    @Query("SELECT * FROM incidents ORDER BY timestamp DESC")
    fun getAllIncidents(): Flow<List<SecurityIncident>>

    @Query("SELECT * FROM incidents WHERE schoolName = :schoolName ORDER BY timestamp DESC")
    fun getIncidentsBySchool(schoolName: String): Flow<List<SecurityIncident>>

    @Query("SELECT * FROM incidents WHERE status = :status ORDER BY timestamp DESC")
    fun getIncidentsByStatus(status: IncidentStatus): Flow<List<SecurityIncident>>

    @Query("SELECT * FROM incidents WHERE partiesInvolved LIKE '%' || :name || '%' OR description LIKE '%' || :name || '%' ORDER BY timestamp DESC")
    fun getIncidentsByParty(name: String): Flow<List<SecurityIncident>>

    @Query("SELECT * FROM incidents WHERE id = :id LIMIT 1")
    suspend fun getIncidentById(id: Long): SecurityIncident?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncident(incident: SecurityIncident): Long

    @Update
    suspend fun updateIncident(incident: SecurityIncident)

    @Delete
    suspend fun deleteIncident(incident: SecurityIncident)

    @Query("DELETE FROM incidents WHERE id = :id")
    suspend fun deleteIncidentById(id: Long)

    @Query("SELECT COUNT(*) FROM incidents")
    suspend fun getCount(): Int

    @Query("DELETE FROM incidents")
    suspend fun deleteAll()
}

// Aliases for EventDao
typealias EventDao = SecurityIncidentDao

@Dao
interface DailyLogDao {
    @Query("SELECT * FROM daily_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<DailyLogEntry>>

    @Query("SELECT * FROM daily_logs WHERE schoolName = :schoolName ORDER BY timestamp DESC")
    fun getLogsBySchool(schoolName: String): Flow<List<DailyLogEntry>>

    @Query("SELECT * FROM daily_logs WHERE teacherName = :teacherName ORDER BY timestamp DESC")
    fun getLogsByTeacher(teacherName: String): Flow<List<DailyLogEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: DailyLogEntry): Long

    @Update
    suspend fun updateLog(log: DailyLogEntry)

    @Delete
    suspend fun deleteLog(log: DailyLogEntry)
}

@Dao
interface TeacherLeaveDao {
    @Query("SELECT * FROM teacher_leaves ORDER BY timestamp DESC")
    fun getAllLeaves(): Flow<List<com.example.data.model.TeacherLeaveEntity>>

    @Query("SELECT * FROM teacher_leaves WHERE teacherId = :teacherId ORDER BY timestamp DESC")
    fun getLeavesByTeacherId(teacherId: Long): Flow<List<com.example.data.model.TeacherLeaveEntity>>

    @Query("SELECT * FROM teacher_leaves WHERE teacherName = :teacherName ORDER BY timestamp DESC")
    fun getLeavesByTeacherName(teacherName: String): Flow<List<com.example.data.model.TeacherLeaveEntity>>

    @Query("SELECT * FROM teacher_leaves WHERE schoolName = :schoolName ORDER BY timestamp DESC")
    fun getLeavesBySchool(schoolName: String): Flow<List<com.example.data.model.TeacherLeaveEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeave(leave: com.example.data.model.TeacherLeaveEntity): Long

    @Update
    suspend fun updateLeave(leave: com.example.data.model.TeacherLeaveEntity)

    @Delete
    suspend fun deleteLeave(leave: com.example.data.model.TeacherLeaveEntity)

    @Query("DELETE FROM teacher_leaves WHERE id = :id")
    suspend fun deleteLeaveById(id: Long)
}

@Dao
interface TeacherPenaltyDao {
    @Query("SELECT * FROM teacher_penalties ORDER BY timestamp DESC")
    fun getAllPenalties(): Flow<List<com.example.data.model.TeacherPenaltyEntity>>

    @Query("SELECT * FROM teacher_penalties WHERE teacherId = :teacherId ORDER BY timestamp DESC")
    fun getPenaltiesByTeacherId(teacherId: Long): Flow<List<com.example.data.model.TeacherPenaltyEntity>>

    @Query("SELECT * FROM teacher_penalties WHERE teacherName = :teacherName ORDER BY timestamp DESC")
    fun getPenaltiesByTeacherName(teacherName: String): Flow<List<com.example.data.model.TeacherPenaltyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPenalty(penalty: com.example.data.model.TeacherPenaltyEntity): Long

    @Update
    suspend fun updatePenalty(penalty: com.example.data.model.TeacherPenaltyEntity)

    @Delete
    suspend fun deletePenalty(penalty: com.example.data.model.TeacherPenaltyEntity)

    @Query("DELETE FROM teacher_penalties WHERE id = :id")
    suspend fun deletePenaltyById(id: Long)
}

@Dao
interface SchoolTripDao {
    @Query("SELECT * FROM school_trips ORDER BY timestamp DESC")
    fun getAllTrips(): Flow<List<com.example.data.model.SchoolTripEntity>>

    @Query("SELECT * FROM school_trips WHERE schoolName = :schoolName ORDER BY timestamp DESC")
    fun getTripsBySchool(schoolName: String): Flow<List<com.example.data.model.SchoolTripEntity>>

    @Query("SELECT * FROM school_trips WHERE schoolId = :schoolId ORDER BY timestamp DESC")
    fun getTripsBySchoolId(schoolId: Long): Flow<List<com.example.data.model.SchoolTripEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrip(trip: com.example.data.model.SchoolTripEntity): Long

    @Update
    suspend fun updateTrip(trip: com.example.data.model.SchoolTripEntity)

    @Delete
    suspend fun deleteTrip(trip: com.example.data.model.SchoolTripEntity)

    @Query("DELETE FROM school_trips WHERE id = :id")
    suspend fun deleteTripById(id: Long)
}

