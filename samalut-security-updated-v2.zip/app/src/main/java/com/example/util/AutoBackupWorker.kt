package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.MainActivity
import com.example.data.local.AppDatabase
import com.example.data.preferences.AdminPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers

class AutoBackupWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        const val CHANNEL_ID = "samalut_security_backup_channel"
        const val NOTIFICATION_ID = 240101
    }

    override suspend fun doWork(): Result {
        return try {
            val db = AppDatabase.getDatabase(applicationContext, CoroutineScope(Dispatchers.IO))
            val adminPrefs = AdminPreferences(applicationContext)

            val result = BackupManager.createFullBackup(
                context = applicationContext,
                database = db,
                adminPreferences = adminPrefs
            )

            if (result.success) {
                showBackupNotification(result)
                Result.success()
            } else {
                Result.retry()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure()
        }
    }

    private fun showBackupNotification(result: BackupResult) {
        val context = applicationContext
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Create Channel on Android 8+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "النسخ الاحتياطي الدوري",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "إشعارات إتمام النسخ الاحتياطي التلقائي لقاعدة بيانات أمن سمالوط"
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("النسخ الاحتياطي التلقائي 🛡️")
            .setContentText("تم حفظ نسخة احتياطية دورية بنجاح (${result.fileSizeFormatted})")
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "تم بنجاح حفظ نسخة احتياطية دورية لقاعدة بيانات ومرفقات أمن سمالوط.\n" +
                            "• إجمالي المدارس: ${result.schoolsCount}\n" +
                            "• إجمالي المعلمين: ${result.teachersCount}\n" +
                            "• الوقائع المسجلة: ${result.incidentsCount}\n" +
                            "• المرفقات المؤرشفة: ${result.attachmentsCount}"
                )
            )
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        } catch (e: SecurityException) {
            // Android 13+ permission may be denied; backup is still completed
            e.printStackTrace()
        }
    }
}
