package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.DailyLogEntry
import com.example.data.model.IncidentStatus
import com.example.data.model.School
import com.example.data.model.SchoolStage
import com.example.data.model.SecurityIncident
import com.example.data.model.Teacher
import com.example.data.repository.SecurityRepository
import com.example.util.ExcelHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SecurityViewModel(
    private val repository: SecurityRepository
) : ViewModel() {

    val allSchools: StateFlow<List<School>> = repository.allSchools
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTeachers: StateFlow<List<Teacher>> = repository.allTeachers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allIncidents: StateFlow<List<SecurityIncident>> = repository.allIncidents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLogs: StateFlow<List<DailyLogEntry>> = repository.allLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLeaves: StateFlow<List<com.example.data.model.TeacherLeaveEntity>> = repository.allLeaves
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPenalties: StateFlow<List<com.example.data.model.TeacherPenaltyEntity>> = repository.allPenalties
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTrips: StateFlow<List<com.example.data.model.SchoolTripEntity>> = repository.allTrips
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val adminConfig = repository.adminConfig

    // Filters & Search
    private val _schoolSearchQuery = MutableStateFlow("")
    val schoolSearchQuery: StateFlow<String> = _schoolSearchQuery.asStateFlow()

    private val _selectedStageFilter = MutableStateFlow<SchoolStage?>(null)
    val selectedStageFilter: StateFlow<SchoolStage?> = _selectedStageFilter.asStateFlow()

    private val _teacherSearchQuery = MutableStateFlow("")
    val teacherSearchQuery: StateFlow<String> = _teacherSearchQuery.asStateFlow()

    private val _incidentSearchQuery = MutableStateFlow("")
    val incidentSearchQuery: StateFlow<String> = _incidentSearchQuery.asStateFlow()

    private val _incidentStatusFilter = MutableStateFlow<IncidentStatus?>(null)
    val incidentStatusFilter: StateFlow<IncidentStatus?> = _incidentStatusFilter.asStateFlow()

    // Import Status Message & Summary
    private val _importMessage = MutableStateFlow<String?>(null)
    val importMessage: StateFlow<String?> = _importMessage.asStateFlow()

    private val _isImporting = MutableStateFlow(false)
    val isImporting: StateFlow<Boolean> = _isImporting.asStateFlow()

    private val _importSummary = MutableStateFlow<com.example.data.repository.ImportSummary?>(null)
    val importSummary: StateFlow<com.example.data.repository.ImportSummary?> = _importSummary.asStateFlow()

    // Backup & Restore StateFlows
    private val _isBackingUp = MutableStateFlow(false)
    val isBackingUp: StateFlow<Boolean> = _isBackingUp.asStateFlow()

    private val _backupResult = MutableStateFlow<com.example.util.BackupResult?>(null)
    val backupResult: StateFlow<com.example.util.BackupResult?> = _backupResult.asStateFlow()

    private val _restoreResult = MutableStateFlow<com.example.util.RestoreResult?>(null)
    val restoreResult: StateFlow<com.example.util.RestoreResult?> = _restoreResult.asStateFlow()

    private val _lastBackupDate = MutableStateFlow("لم يتم إنشاء نسخة بعد")
    val lastBackupDate: StateFlow<String> = _lastBackupDate.asStateFlow()

    private val _isAutoBackupEnabled = MutableStateFlow(true)
    val isAutoBackupEnabled: StateFlow<Boolean> = _isAutoBackupEnabled.asStateFlow()

    // Filtered lists
    val filteredSchools: StateFlow<List<School>> = combine(
        allSchools,
        _schoolSearchQuery,
        _selectedStageFilter
    ) { list, query, stage ->
        list.filter { school ->
            val matchesQuery = query.isBlank() ||
                    school.name.contains(query, ignoreCase = true) ||
                    school.principalName.contains(query, ignoreCase = true) ||
                    school.address.contains(query, ignoreCase = true)
            val matchesStage = stage == null || school.stage == stage
            matchesQuery && matchesStage
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredTeachers: StateFlow<List<Teacher>> = combine(
        allTeachers,
        _teacherSearchQuery,
        _selectedStageFilter
    ) { list, query, stage ->
        list.filter { teacher ->
            val matchesQuery = query.isBlank() ||
                    teacher.name.contains(query, ignoreCase = true) ||
                    teacher.schoolName.contains(query, ignoreCase = true) ||
                    teacher.subject.contains(query, ignoreCase = true) ||
                    teacher.phone.contains(query) ||
                    teacher.nationalId.contains(query)
            val matchesStage = stage == null || teacher.stage == stage
            matchesQuery && matchesStage
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredIncidents: StateFlow<List<SecurityIncident>> = combine(
        allIncidents,
        _incidentSearchQuery,
        _incidentStatusFilter
    ) { list, query, status ->
        list.filter { incident ->
            val matchesQuery = query.isBlank() ||
                    incident.title.contains(query, ignoreCase = true) ||
                    incident.schoolName.contains(query, ignoreCase = true) ||
                    incident.description.contains(query, ignoreCase = true) ||
                    incident.partiesInvolved.contains(query, ignoreCase = true)
            val matchesStatus = status == null || incident.status == status
            matchesQuery && matchesStatus
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setSchoolSearch(query: String) { _schoolSearchQuery.value = query }
    fun setStageFilter(stage: SchoolStage?) { _selectedStageFilter.value = stage }
    fun setTeacherSearch(query: String) { _teacherSearchQuery.value = query }
    fun setIncidentSearch(query: String) { _incidentSearchQuery.value = query }
    fun setIncidentStatusFilter(status: IncidentStatus?) { _incidentStatusFilter.value = status }
    fun clearImportMessage() { _importMessage.value = null }

    // Actions
    fun addSchool(school: School) = viewModelScope.launch { repository.insertSchool(school) }
    fun updateSchool(school: School) = viewModelScope.launch { repository.updateSchool(school) }
    fun deleteSchool(school: School) = viewModelScope.launch { repository.deleteSchool(school) }
    fun deleteSchoolById(id: Long) = viewModelScope.launch { repository.deleteSchoolById(id) }

    fun addTeacher(teacher: Teacher) = viewModelScope.launch { repository.insertTeacher(teacher) }
    fun updateTeacher(teacher: Teacher) = viewModelScope.launch { repository.updateTeacher(teacher) }
    fun deleteTeacher(teacher: Teacher) = viewModelScope.launch { repository.deleteTeacher(teacher) }
    fun deleteTeacherById(id: Long) = viewModelScope.launch { repository.deleteTeacherById(id) }

    fun saveAdminConfig(
        directorate: String,
        administration: String,
        directorGeneral: String,
        securityOfficer: String
    ) {
        repository.saveAdminConfig(directorate, administration, directorGeneral, securityOfficer)
    }

    fun addIncident(incident: SecurityIncident) = viewModelScope.launch { repository.insertIncident(incident) }
    fun updateIncident(incident: SecurityIncident) = viewModelScope.launch { repository.updateIncident(incident) }
    fun deleteIncident(incident: SecurityIncident) = viewModelScope.launch { repository.deleteIncident(incident) }
    fun deleteIncidentById(id: Long) = viewModelScope.launch { repository.deleteIncidentById(id) }

    fun addDailyLog(log: DailyLogEntry) = viewModelScope.launch { repository.insertDailyLog(log) }
    fun updateDailyLog(log: DailyLogEntry) = viewModelScope.launch { repository.updateDailyLog(log) }
    fun deleteDailyLog(log: DailyLogEntry) = viewModelScope.launch { repository.deleteDailyLog(log) }

    // Leaves
    fun addLeave(leave: com.example.data.model.TeacherLeaveEntity) = viewModelScope.launch { repository.insertLeave(leave) }
    fun updateLeave(leave: com.example.data.model.TeacherLeaveEntity) = viewModelScope.launch { repository.updateLeave(leave) }
    fun deleteLeave(leave: com.example.data.model.TeacherLeaveEntity) = viewModelScope.launch { repository.deleteLeave(leave) }
    fun deleteLeaveById(id: Long) = viewModelScope.launch { repository.deleteLeaveById(id) }

    // Penalties
    fun addPenalty(penalty: com.example.data.model.TeacherPenaltyEntity) = viewModelScope.launch { repository.insertPenalty(penalty) }
    fun updatePenalty(penalty: com.example.data.model.TeacherPenaltyEntity) = viewModelScope.launch { repository.updatePenalty(penalty) }
    fun deletePenalty(penalty: com.example.data.model.TeacherPenaltyEntity) = viewModelScope.launch { repository.deletePenalty(penalty) }
    fun deletePenaltyById(id: Long) = viewModelScope.launch { repository.deletePenaltyById(id) }

    // Trips
    fun addTrip(trip: com.example.data.model.SchoolTripEntity) = viewModelScope.launch { repository.insertTrip(trip) }
    fun updateTrip(trip: com.example.data.model.SchoolTripEntity) = viewModelScope.launch { repository.updateTrip(trip) }
    fun deleteTrip(trip: com.example.data.model.SchoolTripEntity) = viewModelScope.launch { repository.deleteTrip(trip) }
    fun deleteTripById(id: Long) = viewModelScope.launch { repository.deleteTripById(id) }

    fun importSchoolsFromText(text: String) {
        viewModelScope.launch {
            _isImporting.value = true
            try {
                val result = ExcelHelper.parseSchoolsFromText(text)
                if (result.items.isNotEmpty()) {
                    val summary = repository.importSchoolsList(result.items)
                    _importSummary.value = summary
                    _importMessage.value = summary.message
                } else {
                    _importMessage.value = "لم يتم العثور على بيانات مدارس صالحة للاستيراد."
                }
            } finally {
                _isImporting.value = false
            }
        }
    }

    fun importSchoolsFromRows(rows: List<List<String>>) {
        viewModelScope.launch {
            _isImporting.value = true
            try {
                val result = ExcelHelper.parseSchoolsFromRows(rows)
                if (result.items.isNotEmpty()) {
                    val summary = repository.importSchoolsList(result.items)
                    _importSummary.value = summary
                    _importMessage.value = summary.message
                } else {
                    _importMessage.value = "لم يتم العثور على بيانات مدارس صالحة للاستيراد في الملف."
                }
            } finally {
                _isImporting.value = false
            }
        }
    }

    fun importTeachersFromText(text: String) {
        viewModelScope.launch {
            _isImporting.value = true
            try {
                val result = ExcelHelper.parseTeachersFromText(text)
                if (result.items.isNotEmpty()) {
                    val summary = repository.importTeachersList(result.items)
                    _importSummary.value = summary
                    _importMessage.value = summary.message
                } else {
                    _importMessage.value = "لم يتم العثور على بيانات معلمين صالحة للاستيراد."
                }
            } finally {
                _isImporting.value = false
            }
        }
    }

    fun importTeachersFromRows(rows: List<List<String>>) {
        viewModelScope.launch {
            _isImporting.value = true
            try {
                val result = ExcelHelper.parseTeachersFromRows(rows)
                if (result.items.isNotEmpty()) {
                    val summary = repository.importTeachersList(result.items)
                    _importSummary.value = summary
                    _importMessage.value = summary.message
                } else {
                    _importMessage.value = "لم يتم العثور على بيانات معلمين صالحة للاستيراد في الملف."
                }
            } finally {
                _isImporting.value = false
            }
        }
    }

    fun dismissImportSummary() {
        _importSummary.value = null
    }

    // Backup & Restore Actions
    fun refreshBackupStatus(context: android.content.Context) {
        _lastBackupDate.value = com.example.util.BackupScheduler.getLastBackupDate(context)
        _isAutoBackupEnabled.value = com.example.util.BackupScheduler.isAutoBackupEnabled(context)
    }

    fun setAutoBackupEnabled(context: android.content.Context, enabled: Boolean) {
        _isAutoBackupEnabled.value = enabled
        if (enabled) {
            com.example.util.BackupScheduler.schedulePeriodicBackup(context)
        } else {
            com.example.util.BackupScheduler.cancelPeriodicBackup(context)
        }
    }

    fun createBackupNow(context: android.content.Context) {
        viewModelScope.launch {
            _isBackingUp.value = true
            try {
                val res = repository.createBackup(context)
                _backupResult.value = res
                _lastBackupDate.value = com.example.util.BackupScheduler.getLastBackupDate(context)
            } finally {
                _isBackingUp.value = false
            }
        }
    }

    fun restoreBackup(context: android.content.Context, zipUriOrFile: Any) {
        viewModelScope.launch {
            _isBackingUp.value = true
            try {
                val res = repository.restoreBackup(context, zipUriOrFile)
                _restoreResult.value = res
            } finally {
                _isBackingUp.value = false
            }
        }
    }

    fun dismissBackupResult() {
        _backupResult.value = null
    }

    fun dismissRestoreResult() {
        _restoreResult.value = null
    }

    fun resetData() = viewModelScope.launch {
        repository.resetAllData()
        _importMessage.value = "تمت استعادة البيانات الافتراضية لإدارة سمالوط بنجاح."
    }
}

class SecurityViewModelFactory(private val repository: SecurityRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SecurityViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SecurityViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
