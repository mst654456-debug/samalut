package com.example.util

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * المساعد الذكي من خارج البرنامج: يرسل السؤال العام فقط إلى Gemini (بدون أي بيانات مدارس أو معلمين).
 * المفتاح يُقرأ من BuildConfig.GEMINI_API_KEY (يأتي من ملف .env أثناء البناء).
 */
object GeminiAssistant {

    private const val MODEL = "gemini-2.5-flash"
    private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    private val client by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    private const val SYSTEM_PROMPT =
        "أنت مساعد ذكي داخل تطبيق إدارة أمن الإدارة التعليمية بسمالوط (محافظة المنيا، مصر). " +
        "أجب باللغة العربية بإيجاز ووضوح وبشكل عملي. أسئلتك قد تكون عن الأمن المدرسي والسلامة " +
        "والإجراءات الإدارية واللوائح التعليمية وصياغة الخطابات والتقارير أو أي موضوع عام. " +
        "لا تختلق معلومات؛ إذا لم تكن متأكداً فقل ذلك."

    private fun apiKey(): String = try {
        val cls = Class.forName("com.example.BuildConfig")
        (cls.getField("GEMINI_API_KEY").get(null) as? String).orEmpty()
    } catch (e: Throwable) {
        ""
    }.let { if (it == "MY_GEMINI_API_KEY") "" else it }

    fun isConfigured(): Boolean = apiKey().isNotBlank()

    suspend fun ask(question: String): Result<String> = withContext(Dispatchers.IO) {
        val key = apiKey()
        if (key.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("خدمة Gemini غير مفعّلة في هذه النسخة. تواصل مع مطوّر البرنامج لتفعيلها.")
            )
        }
        try {
            val body = JSONObject().apply {
                put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))))
                put(
                    "contents",
                    JSONArray().put(
                        JSONObject()
                            .put("role", "user")
                            .put("parts", JSONArray().put(JSONObject().put("text", question)))
                    )
                )
            }
            val request = Request.Builder()
                .url(ENDPOINT)
                .addHeader("x-goog-api-key", key)
                .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val msg = try {
                        JSONObject(raw).getJSONObject("error").getString("message")
                    } catch (_: Exception) {
                        "HTTP ${response.code}"
                    }
                    return@withContext Result.failure(Exception("تعذر الحصول على رد: $msg"))
                }
                val text = JSONObject(raw)
                    .getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .let { parts ->
                        (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text", "") }
                    }
                if (text.isBlank()) Result.failure(Exception("لم يصل رد من Gemini")) else Result.success(text.trim())
            }
        } catch (e: java.io.IOException) {
            Result.failure(Exception("تعذر الاتصال بالإنترنت. تأكد من الاتصال وأعد المحاولة."))
        } catch (e: Exception) {
            Result.failure(Exception("حدث خطأ أثناء معالجة الرد: ${e.message}"))
        }
    }
}
