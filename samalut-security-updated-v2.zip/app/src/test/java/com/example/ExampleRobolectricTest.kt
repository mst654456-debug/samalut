package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.Converters
import com.example.data.model.IncidentStatus
import com.example.data.model.School
import com.example.data.model.SchoolStage
import com.example.data.model.SecurityIncident
import com.example.data.model.VicePrincipal
import com.example.util.ExcelHelper
import com.example.util.WhatsAppHelper
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  private lateinit var db: AppDatabase

  @Before
  fun createDb() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
      .allowMainThreadQueries()
      .build()
  }

  @After
  fun closeDb() {
    db.close()
  }

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("أمن سمالوط", appName)
  }

  @Test
  fun `test whatsapp egyptian number formatting`() {
    val formatted1 = WhatsAppHelper.formatEgyptianNumber("01004567891")
    assertEquals("201004567891", formatted1)

    val formatted2 = WhatsAppHelper.formatEgyptianNumber("+201123456789")
    assertEquals("201123456789", formatted2)
  }

  @Test
  fun `test school entity room operations with stages and vice principals`() = runBlocking {
    val schoolDao = db.schoolDao()
    val school = School(
      governorate = "المنيا",
      administration = "سمالوط التعليمية",
      name = "مدرسة سمالوط التجريبية لغات",
      stage = SchoolStage.KINDERGARTEN,
      principalName = "أ/ إبراهيم فهمي",
      principalPhone = "01011223344",
      vicePrincipals = listOf(
        VicePrincipal(name = "أ/ رانيا", phone = "01099887766"),
        VicePrincipal(name = "أ/ ماجد", phone = "01233445566")
      ),
      securityOfficerName = "مستر مصطفى فرغلي",
      securityOfficerPhone = "01005556677",
      classroomsCount = 12,
      teachersCount = 25,
      workersCount = 4,
      buildingsCount = 1,
      extinguishersCount = 6,
      camerasCount = 8
    )

    val id = schoolDao.insertSchool(school)
    val fetched = schoolDao.getSchoolById(id)
    assertEquals("المنيا", fetched?.governorate)
    assertEquals("سمالوط التعليمية", fetched?.administration)
    assertEquals(2, fetched?.vicePrincipals?.size)
    assertEquals(SchoolStage.KINDERGARTEN, fetched?.stage)

    // Test filter by stage
    val kgSchools = schoolDao.getSchoolsByStage(SchoolStage.KINDERGARTEN).first()
    assertEquals(1, kgSchools.size)

    // Test update
    val updated = fetched!!.copy(camerasCount = 10)
    schoolDao.updateSchool(updated)
    val afterUpdate = schoolDao.getSchoolById(id)
    assertEquals(10, afterUpdate?.camerasCount)

    // Test delete
    schoolDao.deleteSchool(afterUpdate!!)
    val afterDelete = schoolDao.getSchoolById(id)
    assertEquals(null, afterDelete)
  }

  @Test
  fun `test event entity room operations with multiple image uris and status`() = runBlocking {
    val incidentDao = db.securityIncidentDao()
    val incident = SecurityIncident(
      title = "فحص منظومة الكاميرات بالسور الغربي",
      description = "تم تفقد الكاميرات والتأكد من التسجيل المنتظم",
      schoolName = "مدرسة سمالوط الثانوية بنين",
      partiesInvolved = "فريق الصيانة x مسؤول الأمن",
      actionTaken = "تم استبدال محول الطاقة",
      status = IncidentStatus.RESOLVED,
      imageUris = listOf("content://media/1", "content://media/2", "content://media/3")
    )

    val id = incidentDao.insertIncident(incident)
    val fetched = incidentDao.getIncidentById(id)
    assertEquals(IncidentStatus.RESOLVED, fetched?.status)
    assertEquals(3, fetched?.imageUris?.size)
    assertEquals("content://media/1", fetched?.imageUris?.get(0))

    // Test filter by status
    val resolvedList = incidentDao.getIncidentsByStatus(IncidentStatus.RESOLVED).first()
    assertEquals(1, resolvedList.size)

    // Test update incident (e.g. changing title, status, and photos)
    val updatedIncident = fetched!!.copy(
      title = "تم التحديث: فحص منظومة الكاميرات",
      status = IncidentStatus.CLOSED,
      imageUris = listOf("content://media/1", "content://media/2")
    )
    incidentDao.updateIncident(updatedIncident)
    val afterIncidentUpdate = incidentDao.getIncidentById(id)
    assertEquals("تم التحديث: فحص منظومة الكاميرات", afterIncidentUpdate?.title)
    assertEquals(IncidentStatus.CLOSED, afterIncidentUpdate?.status)
    assertEquals(2, afterIncidentUpdate?.imageUris?.size)

    // Test delete by id
    incidentDao.deleteIncidentById(id)
    val afterDelete = incidentDao.getIncidentById(id)
    assertEquals(null, afterDelete)
  }

  @Test
  fun `test excel parser with sample schools`() {
    val sample = ExcelHelper.getSampleSchoolsCsv()
    val result = ExcelHelper.parseSchoolsFromText(sample)
    assertTrue(result.items.isNotEmpty())
    assertEquals("مدرسة سمالوط الثانوية بنين", result.items[0].name)
    assertEquals("SCH-240101", result.items[0].code)
    assertEquals(SchoolStage.GENERAL_SECONDARY, result.items[0].stage)
    assertEquals(16, result.items[0].camerasCount)
  }

  @Test
  fun `test school with maximum 4 vice principals`() = runBlocking {
    val schoolDao = db.schoolDao()
    val vps = listOf(
      VicePrincipal("وكيل 1", "0101"),
      VicePrincipal("وكيل 2", "0102"),
      VicePrincipal("وكيل 3", "0103"),
      VicePrincipal("وكيل 4", "0104")
    )
    val school = School(
      governorate = "المنيا",
      administration = "سمالوط التعليمية",
      name = "مدرسة التجربة الكبرى",
      stage = SchoolStage.GENERAL_SECONDARY,
      vicePrincipals = vps
    )
    val id = schoolDao.insertSchool(school)
    val fetched = schoolDao.getSchoolById(id)
    assertEquals(4, fetched?.vicePrincipals?.size)
    assertEquals("وكيل 4", fetched?.vicePrincipals?.get(3)?.name)
  }

  @Test
  fun `test report exporter official date format`() {
    val date = java.util.Date()
    val formatted = com.example.util.ReportExporter.formatOfficialDayDate(date)
    assertTrue(formatted.isNotBlank())
    // Should contain day name and slash formatted date digits
    assertTrue(formatted.contains("/"))
  }

  @Test
  fun `test clearance certificate report generation in DOCX when no incidents exist`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val testDate = java.util.Date()
    val emptyIncidents = emptyList<SecurityIncident>()

    val docxFile = com.example.util.ReportExporter.generateDailyReportDocx(
      context = context,
      date = testDate,
      incidents = emptyIncidents,
      supervisorName = "مستر مصطفى فرغلي"
    )

    assertTrue(docxFile.exists())
    assertTrue(docxFile.length() > 0)

    // Verify DOCX ZIP archive contents
    val zip = java.util.zip.ZipFile(docxFile)
    val documentEntry = zip.getEntry("word/document.xml")
    org.junit.Assert.assertNotNull(documentEntry)

    val content = zip.getInputStream(documentEntry).bufferedReader().use { it.readText() }
    zip.close()

    // Verify required Arabic layout and wording
    assertTrue(content.contains("مديرية التربية والتعليم بالمنيا"))
    assertTrue(content.contains("إدارة سمالوط التعليمية"))
    assertTrue(content.contains("تقرير الأحداث اليومية للمدارس"))
    assertTrue(content.contains("لا توجد أحداث بالإدارة لهذا اليوم"))
    assertTrue(content.contains("إعداد / مسئول الأمن"))
    assertTrue(content.contains("مستر مصطفى فرغلي"))
    assertTrue(content.contains("يعتمد / مدير عام الإدارة"))
  }

  @Test
  fun `test clearance certificate report generation in PDF when no incidents exist`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val testDate = java.util.Date()
    val emptyIncidents = emptyList<SecurityIncident>()

    val pdfFile = com.example.util.ReportExporter.generateDailyReportPdf(
      context = context,
      date = testDate,
      incidents = emptyIncidents,
      supervisorName = "مستر مصطفى فرغلي"
    )

    assertTrue(pdfFile.exists())
    assertTrue(pdfFile.length() > 0)
  }

  @Test
  fun `test admin preferences persistence and config updates`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val adminPrefs = com.example.data.preferences.AdminPreferences(context)

    // Test initial default values
    val initial = adminPrefs.adminConfig.value
    assertEquals("مديرية التربية والتعليم بالمنيا", initial.directorateName)
    assertEquals("إدارة سمالوط التعليمية", initial.administrationName)

    // Test save config
    adminPrefs.saveConfig(
      directorate = "مديرية المنيا التعليمية",
      administration = "إدارة سمالوط",
      directorGeneral = "د/ أحمد عبد العزيز",
      securityOfficer = "مستر مصطفى فرغلي",
      isCompleted = true
    )

    val updated = adminPrefs.adminConfig.value
    assertEquals("مديرية المنيا التعليمية", updated.directorateName)
    assertEquals("إدارة سمالوط", updated.administrationName)
    assertEquals("د/ أحمد عبد العزيز", updated.directorGeneralName)
    assertEquals("مستر مصطفى فرغلي", updated.securityOfficerName)
    assertTrue(updated.isSetupCompleted)
  }

  @Test
  fun `test school entity with code, serial number, notes and attached files`() = runBlocking {
    val schoolDao = db.schoolDao()
    val school = School(
      name = "مدرسة التجريبية الحديثة",
      code = "SCH-3849",
      serialNumber = "SN-0012",
      stage = SchoolStage.PRIMARY,
      notes = "مدرسة رائدة في التجهيزات الأمنية",
      attachedFiles = listOf("/data/user/0/com.example/files/attachments/school_cert.pdf", "/data/user/0/com.example/files/attachments/school_plan.jpg")
    )

    val id = schoolDao.insertSchool(school)
    val fetched = schoolDao.getSchoolById(id)
    assertEquals("SCH-3849", fetched?.code)
    assertEquals("SN-0012", fetched?.serialNumber)
    assertEquals("مدرسة رائدة في التجهيزات الأمنية", fetched?.notes)
    assertEquals(2, fetched?.attachedFiles?.size)
  }

  @Test
  fun `test teacher entity with code, assigned duty, notes and attached files`() = runBlocking {
    val teacherDao = db.teacherDao()
    val teacher = com.example.data.model.Teacher(
      name = "أ/ طارق محمود حسن",
      teacherCode = "TCH-9921",
      nationalId = "28910101802931",
      schoolName = "مدرسة سمالوط الثانوية بنين",
      stage = SchoolStage.GENERAL_SECONDARY,
      jobTitle = "معلم أول أ لغة عربية",
      assignedDuty = "مشرف أمن الدور الأول ولجنة الطوارئ",
      phone = "01099887766",
      notes = "مسؤول عن متابعة طفايات الحريق بالمبنى ب",
      attachedFiles = listOf("/data/user/0/com.example/files/attachments/duty_assignment.pdf")
    )

    val id = teacherDao.insertTeacher(teacher)
    val fetched = teacherDao.getTeacherById(id)
    assertEquals("TCH-9921", fetched?.teacherCode)
    assertEquals("مشرف أمن الدور الأول ولجنة الطوارئ", fetched?.assignedDuty)
    assertEquals(1, fetched?.attachedFiles?.size)

    // Test delete by id
    teacherDao.deleteTeacherById(id)
    val afterDelete = teacherDao.getTeacherById(id)
    assertEquals(null, afterDelete)
  }

  @Test
  fun `test custom admin config in docx report export`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val testDate = java.util.Date()
    val config = com.example.data.preferences.AdminConfig(
      directorateName = "مديرية التربية والتعليم بالمنيا",
      administrationName = "إدارة سمالوط التعليمية",
      directorGeneralName = "د/ أحمد عبد العزيز",
      securityOfficerName = "مستر مصطفى فرغلي",
      isSetupCompleted = true
    )

    val docxFile = com.example.util.ReportExporter.generateDailyReportDocx(
      context = context,
      date = testDate,
      incidents = emptyList(),
      adminConfig = config
    )

    assertTrue(docxFile.exists())
    val zip = java.util.zip.ZipFile(docxFile)
    val documentEntry = zip.getEntry("word/document.xml")
    val content = zip.getInputStream(documentEntry).bufferedReader().use { it.readText() }
    zip.close()

    assertTrue(content.contains("مديرية التربية والتعليم بالمنيا"))
    assertTrue(content.contains("إدارة سمالوط التعليمية"))
    assertTrue(content.contains("مستر مصطفى فرغلي"))
    assertTrue(content.contains("د/ أحمد عبد العزيز"))
  }

  @Test
  fun `test 16 column school sheet parsing and mapping`() {
    val sample = """الرقم المسلسل,اسم المدرسة,المرحلة,كود المدرسة,اسم المدير,هاتف المدير,اسم الوكيل,هاتف الوكيل,مسؤول الأمن,هاتف مسؤول الأمن,عدد الفصول,عدد العاملين,عدد الكاميرات,عدد المباني,عدد العمال,الملاحظات
SN-100,مدرسة التجربة الحديثة,ابتدائي,SCH-9988,أ/ ممدوح أحمد,01011112222,أ/ كريم عادل,01233334444,أ/ سامح فهمي,01155556666,15,40,14,2,7,ملاحظات تأمين فناء المدرسة"""

    val result = ExcelHelper.parseSchoolsFromText(sample)
    assertEquals(1, result.items.size)
    val school = result.items[0]
    assertEquals("SN-100", school.serialNumber)
    assertEquals("مدرسة التجربة الحديثة", school.name)
    assertEquals(SchoolStage.PRIMARY, school.stage)
    assertEquals("SCH-9988", school.code)
    assertEquals("أ/ ممدوح أحمد", school.principalName)
    assertEquals("01011112222", school.principalPhone)
    assertEquals(1, school.vicePrincipals.size)
    assertEquals("أ/ كريم عادل", school.vicePrincipals[0].name)
    assertEquals("01233334444", school.vicePrincipals[0].phone)
    assertEquals("أ/ سامح فهمي", school.securityOfficerName)
    assertEquals("01155556666", school.securityOfficerPhone)
    assertEquals(15, school.classroomsCount)
    assertEquals(40, school.teachersCount)
    assertEquals(14, school.camerasCount)
    assertEquals(2, school.buildingsCount)
    assertEquals(7, school.workersCount)
    assertEquals("ملاحظات تأمين فناء المدرسة", school.notes)
  }

  @Test
  fun `test 10 column teacher sheet parsing and mapping`() {
    val sample = """م,الاسم,كود المعلم,الرقم القومي,اسم المدرسة,الوظيفة,العمل المكلف به,رقم التليفون,العنوان,الملاحظات
1,أ/ حسام فاروق جودة,TCH-7788,29011141700123,مدرسة سمالوط الثانوية بنين,معلم أول لغة عربية,مشرف أمن المبنى ج,01122339900,مركز سمالوط - ش التجارة,عضو لجنة إدارة الأزمات"""

    val result = ExcelHelper.parseTeachersFromText(sample)
    assertEquals(1, result.items.size)
    val teacher = result.items[0]
    assertEquals("أ/ حسام فاروق جودة", teacher.name)
    assertEquals("TCH-7788", teacher.teacherCode)
    assertEquals("29011141700123", teacher.nationalId)
    assertEquals("مدرسة سمالوط الثانوية بنين", teacher.schoolName)
    assertEquals("معلم أول لغة عربية", teacher.jobTitle)
    assertEquals("مشرف أمن المبنى ج", teacher.assignedDuty)
    assertEquals("01122339900", teacher.phone)
    assertEquals("مركز سمالوط - ش التجارة", teacher.address)
    assertEquals("عضو لجنة إدارة الأزمات", teacher.notes)
  }

  @Test
  fun `test import schools avoiding duplicate school code`() = runBlocking {
    val repository = com.example.data.repository.SecurityRepository(db)

    // 1. Initial insert of school
    val initialSchool = School(
      name = "مدرسة سمالوط التجريبية",
      code = "SCH-001",
      stage = SchoolStage.PRIMARY,
      camerasCount = 6
    )
    repository.insertSchool(initialSchool)
    assertEquals(1, db.schoolDao().getCount())

    // 2. Import school with SAME code but updated camera count and name
    val importedSchool = School(
      name = "مدرسة سمالوط التجريبية الرسمية لغات",
      code = "SCH-001",
      stage = SchoolStage.PRIMARY,
      camerasCount = 18,
      notes = "تم تحديث المنظومة"
    )

    val summary = repository.importSchoolsList(listOf(importedSchool))
    assertEquals(0, summary.addedCount)
    assertEquals(1, summary.updatedCount)
    // Total count in database must remain 1 (no duplicate!)
    assertEquals(1, db.schoolDao().getCount())

    val fetched = db.schoolDao().getSchoolByCode("SCH-001")
    assertEquals(18, fetched?.camerasCount)
    assertEquals("مدرسة سمالوط التجريبية الرسمية لغات", fetched?.name)
    assertEquals("تم تحديث المنظومة", fetched?.notes)
  }

  @Test
  fun `test import teachers linking to school and avoiding duplicates`() = runBlocking {
    val repository = com.example.data.repository.SecurityRepository(db)

    // Add school with PREPARATORY stage
    db.schoolDao().insertSchool(
      School(name = "مدرسة قلوصنا الإعدادية المشتركة", stage = SchoolStage.PREPARATORY)
    )

    // 1. Initial insert of teacher
    val initialTeacher = com.example.data.model.Teacher(
      name = "أ/ رأفت نصحي فهيم",
      teacherCode = "TCH-5544",
      nationalId = "28903101700765",
      schoolName = "مدرسة قلوصنا الإعدادية المشتركة",
      stage = SchoolStage.PRIMARY, // initial mismatch
      phone = "01233445566"
    )
    repository.insertTeacher(initialTeacher)
    assertEquals(1, db.teacherDao().getCount())

    // 2. Import teacher with SAME teacherCode but updated duty and phone
    val updateTeacherImport = com.example.data.model.Teacher(
      name = "أ/ رأفت نصحي فهيم",
      teacherCode = "TCH-5544",
      nationalId = "28903101700765",
      schoolName = "مدرسة قلوصنا الإعدادية المشتركة",
      stage = SchoolStage.PRIMARY,
      jobTitle = "معلم أول رياضيات",
      assignedDuty = "مشرف أمن الفناء الداخلي",
      phone = "01299998888"
    )

    val summary = repository.importTeachersList(listOf(updateTeacherImport))
    assertEquals(0, summary.addedCount)
    assertEquals(1, summary.updatedCount)
    // Total count in database must remain 1 (no duplicate!)
    assertEquals(1, db.teacherDao().getCount())

    val fetched = db.teacherDao().getTeacherByCode("TCH-5544")
    assertEquals("01299998888", fetched?.phone)
    assertEquals("مشرف أمن الفناء الداخلي", fetched?.assignedDuty)
    // Verified: teacher stage automatically linked to school stage (PREPARATORY)!
    assertEquals(SchoolStage.PREPARATORY, fetched?.stage)
  }

  @Test
  fun `test teacher leave creation, calculation, and active status`() = runBlocking {
    val leaveDao = db.teacherLeaveDao()
    val today = java.text.SimpleDateFormat("yyyy/MM/dd", java.util.Locale.US).format(java.util.Date())

    val activeLeave = com.example.data.model.TeacherLeaveEntity(
      teacherId = 101L,
      teacherName = "أ/ محمد سمير",
      schoolName = "مدرسة سمالوط الثانوية بنين",
      leaveType = "اعتيادي",
      startDate = today,
      endDate = today,
      daysCount = 1,
      destination = "داخل القطر (محافظة المنيا)",
      notes = "إجازة دورية اعتيادية"
    )

    val id = leaveDao.insertLeave(activeLeave)
    val fetched = leaveDao.getLeavesByTeacherId(101L).first()
    assertEquals(1, fetched.size)
    assertEquals("اعتيادي", fetched[0].leaveType)
    assertEquals(1, fetched[0].daysCount)
    assertTrue(fetched[0].isCurrentlyActive)

    // Test delete
    leaveDao.deleteLeave(fetched[0])
    val afterDelete = leaveDao.getLeavesByTeacherId(101L).first()
    assertEquals(0, afterDelete.size)
  }

  @Test
  fun `test teacher penalty recording and query`() = runBlocking {
    val penaltyDao = db.teacherPenaltyDao()
    val penalty = com.example.data.model.TeacherPenaltyEntity(
      teacherId = 202L,
      teacherName = "أ/ حسام ربيع",
      schoolName = "مدرسة بني خالد الإعدادية",
      penaltyType = "خصم من الراتب",
      daysDeducted = 3,
      reason = "الغياب بدون إذن مسبق وعدم الالتزام بجدول الحصص",
      issuingAuthority = "الشؤون القانونية بالإدارة",
      decisionNumber = "ق-45/2024",
      dateString = "10 / 11 / 2024",
      notes = "تم إخطار المدرسة لتنفيذ الخصم"
    )

    val id = penaltyDao.insertPenalty(penalty)
    val penalties = penaltyDao.getPenaltiesByTeacherId(202L).first()
    assertEquals(1, penalties.size)
    assertEquals("خصم من الراتب", penalties[0].penaltyType)
    assertEquals(3, penalties[0].daysDeducted)
    assertEquals("ق-45/2024", penalties[0].decisionNumber)
  }

  @Test
  fun `test school trip recording and official itinerary statement generation`() = runBlocking {
    val tripDao = db.schoolTripDao()
    val trip = com.example.data.model.SchoolTripEntity(
      schoolId = 303L,
      schoolName = "مدرسة سمالوط الإعدادية بنات",
      destination = "متحف الحضارات بالقاهرة",
      tripDate = "18 / 11 / 2024",
      assemblyTime = "06:30 صباحاً",
      supervisors = listOf("أ/ فاطمة أحمد", "أ/ سارة محمود", "أ/ نجلاء سيد"),
      studentsCount = 48,
      transportCompany = "شركة حورس للسياحة والنقل",
      busNumber = "أ ب ج 9876",
      routePlan = "سمالوط -> طريق الجيش -> القاهرة -> المتحف -> العودة 6:00 م",
      securityInstructions = "توافر حقيبة إسعافات، التأكد من رخصة السائق والالتزام بمواعيد التحرك",
      approvalStatus = "معتمدة من أمن الإدارة"
    )

    val id = tripDao.insertTrip(trip)
    val trips = tripDao.getTripsBySchoolId(303L).first()
    assertEquals(1, trips.size)
    assertEquals(3, trips[0].supervisors.size)
    assertEquals("متحف الحضارات بالقاهرة", trips[0].destination)

    // Test official itinerary generation
    val config = com.example.data.preferences.AdminConfig(
      directorateName = "مديرية التربية والتعليم بالمنيا",
      administrationName = "إدارة سمالوط التعليمية",
      directorGeneralName = "د/ بهاء حسن",
      securityOfficerName = "مستر مصطفى فرغلي"
    )
    val text = com.example.util.TripReportHelper.generateTripItineraryText(trips[0], config)
    assertTrue(text.contains("بيان خط سير وتأمين رحلة مدرسية رسمية"))
    assertTrue(text.contains("مدرسة سمالوط الإعدادية بنات"))
    assertTrue(text.contains("متحف الحضارات بالقاهرة"))
    assertTrue(text.contains("أ/ فاطمة أحمد"))
    assertTrue(text.contains("مستر مصطفى فرغلي"))
    assertTrue(text.contains("د/ بهاء حسن"))
  }

  @Test
  fun `test smart query engine responses for leaves and trips`() {
    val school = School(id = 1L, name = "مدرسة سمالوط الثانوية بنين", stage = SchoolStage.GENERAL_SECONDARY)
    val teacher = com.example.data.model.Teacher(id = 1L, name = "أ/ طارق عبد الله", schoolName = "مدرسة سمالوط الثانوية بنين", stage = SchoolStage.GENERAL_SECONDARY)
    val leave = com.example.data.model.TeacherLeaveEntity(
      teacherId = 1L,
      teacherName = "أ/ طارق عبد الله",
      schoolName = "مدرسة سمالوط الثانوية بنين",
      leaveType = "اعتيادي",
      startDate = "2024/11/01",
      endDate = "2024/11/15",
      daysCount = 14
    )
    val trip = com.example.data.model.SchoolTripEntity(
      schoolId = 1L,
      schoolName = "مدرسة سمالوط الثانوية بنين",
      destination = "بانوراما حرب أكتوبر",
      tripDate = "2024/11/20"
    )

    // Query 1: Leaves
    val leaveRes = com.example.util.SmartQueryEngine.processNaturalLanguageQuery(
      query = "مين عنده إجازة في المدارس؟",
      schools = listOf(school),
      teachers = listOf(teacher),
      incidents = emptyList(),
      leaves = listOf(leave),
      penalties = emptyList(),
      trips = listOf(trip)
    )
    assertEquals(1, leaveRes.rawResultsCount)
    assertTrue(leaveRes.formattedDetails.contains("أ/ طارق عبد الله"))
    assertTrue(leaveRes.formattedDetails.contains("اعتيادي"))

    // Query 2: Trips
    val tripRes = com.example.util.SmartQueryEngine.processNaturalLanguageQuery(
      query = "إيه الرحلات والفعاليات بمدرسة سمالوط الثانوية بنين؟",
      schools = listOf(school),
      teachers = listOf(teacher),
      incidents = emptyList(),
      leaves = listOf(leave),
      penalties = emptyList(),
      trips = listOf(trip)
    )
    assertEquals(1, tripRes.rawResultsCount)
    assertTrue(tripRes.formattedDetails.contains("بانوراما حرب أكتوبر"))
  }
}


