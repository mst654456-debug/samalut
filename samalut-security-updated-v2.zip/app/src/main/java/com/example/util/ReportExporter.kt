package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.IncidentStatus
import com.example.data.model.SecurityIncident
import com.example.data.preferences.AdminConfig
import java.io.File
import java.io.FileOutputStream
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ReportExporter {

    enum class ReportPeriod(val titleAr: String) {
        DAILY("التقرير اليومي"),
        WEEKLY("التقرير الأسبوعي"),
        MONTHLY("التقرير الشهري"),
        ANNUAL("التقرير السنوي")
    }

    /**
     * تنسيق اليوم والتاريخ بالتنسيق المطلوب:
     * [اليوم] [DD / MM / YYYY]
     * مثال: الثلاثاء 03 / 11 / 2026
     */
    fun formatOfficialDayDate(date: Date): String {
        val cal = Calendar.getInstance().apply { time = date }
        val dayNameAr = when (cal.get(Calendar.DAY_OF_WEEK)) {
            Calendar.SATURDAY -> "السبت"
            Calendar.SUNDAY -> "الأحد"
            Calendar.MONDAY -> "الإثنين"
            Calendar.TUESDAY -> "الثلاثاء"
            Calendar.WEDNESDAY -> "الأربعاء"
            Calendar.THURSDAY -> "الخميس"
            Calendar.FRIDAY -> "الجمعة"
            else -> "اليوم"
        }
        val dateDigits = SimpleDateFormat("dd / MM / yyyy", Locale.US).format(date)
        return "$dayNameAr $dateDigits"
    }

    /**
     * فلترة الأحداث بحسب تاريخ محدد
     */
    fun filterIncidentsByDate(incidents: List<SecurityIncident>, date: Date): List<SecurityIncident> {
        val targetDateStr1 = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(date)
        val targetDateStr2 = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(date)

        val targetCal = Calendar.getInstance().apply { time = date }
        val targetYear = targetCal.get(Calendar.YEAR)
        val targetDayOfYear = targetCal.get(Calendar.DAY_OF_YEAR)

        return incidents.filter { incident ->
            val incDate = incident.dateString.trim().replace('-', '/')
            if (incDate == targetDateStr1.replace('-', '/') || incDate == targetDateStr2.replace('-', '/')) {
                return@filter true
            }
            if (incident.timestamp > 0) {
                val incCal = Calendar.getInstance().apply { timeInMillis = incident.timestamp }
                if (incCal.get(Calendar.YEAR) == targetYear && incCal.get(Calendar.DAY_OF_YEAR) == targetDayOfYear) {
                    return@filter true
                }
            }
            false
        }
    }

    /**
     * توليد ملف PDF باستخدام PdfDocument الرسمي في أندرويد
     * يطبق شرط "تقرير خلو الأحداث" إذا لم تكن هناك أحداث مسجلة لهذا اليوم.
     */
    fun generateDailyReportPdf(
        context: Context,
        date: Date,
        incidents: List<SecurityIncident>,
        adminConfig: AdminConfig = AdminConfig()
    ): File {
        val dayIncidents = filterIncidentsByDate(incidents, date)
        val dayDateText = formatOfficialDayDate(date)

        val dateSlug = SimpleDateFormat("yyyy_MM_dd", Locale.US).format(date)
        val admSlug = adminConfig.administrationName.replace(" ", "_")
        val fileName = if (dayIncidents.isEmpty()) "إفادة_خلو_أحداث_${admSlug}_$dateSlug.pdf" else "تقرير_أحداث_${admSlug}_$dateSlug.pdf"
        val outFile = File(context.cacheDir, fileName)

        try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 size in points
            val page = pdfDocument.startPage(pageInfo)
            val canvas: Canvas = page.canvas

            val marginStart = 40f
            val marginEnd = 555f
            val pageWidth = 595f

            // إعداد أقلام الرسم (Paints)
            val headerRightPaint = Paint().apply {
                color = Color.rgb(20, 30, 50)
                textSize = 14f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.RIGHT
                isAntiAlias = true
            }

            val headerTitlePaint = Paint().apply {
                color = Color.rgb(21, 101, 192) // EduBlue
                textSize = 18f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.LEFT
                isAntiAlias = true
            }

            val linePaint = Paint().apply {
                color = Color.rgb(21, 101, 192)
                strokeWidth = 2f
                style = Paint.Style.STROKE
                isAntiAlias = true
            }

            val footerLinePaint = Paint().apply {
                color = Color.rgb(180, 190, 200)
                strokeWidth = 1.5f
                style = Paint.Style.STROKE
                isAntiAlias = true
            }

            // 1. الترويسة العلوية:
            // - جهة اليمين: المديرية / الإدارة
            canvas.drawText(adminConfig.directorateName, marginEnd, 55f, headerRightPaint)
            canvas.drawText(adminConfig.administrationName, marginEnd, 75f, headerRightPaint)
            canvas.drawText("مكتب الأمن", marginEnd, 95f, headerRightPaint)

            // - جهة اليسار / المنتصف: عنوان رئيسي عريض: "تقرير الأحداث اليومية للمدارس"
            canvas.drawText("تقرير الأحداث اليومية للمدارس", marginStart, 75f, headerTitlePaint)

            // - خط فاصل أفقي أسفل الترويسة بعرض الصفحة
            canvas.drawLine(marginStart, 115f, marginEnd, 115f, linePaint)

            // 2. منتصف الصفحة:
            if (dayIncidents.isEmpty()) {
                // حالة خلو الأحداث: إفادة رسمية
                val boxRect = RectF(60f, 320f, 535f, 480f)
                val boxBgPaint = Paint().apply {
                    color = Color.rgb(240, 248, 255)
                    style = Paint.Style.FILL
                    isAntiAlias = true
                }
                val boxStrokePaint = Paint().apply {
                    color = Color.rgb(21, 101, 192)
                    style = Paint.Style.STROKE
                    strokeWidth = 1.5f
                    isAntiAlias = true
                }
                canvas.drawRoundRect(boxRect, 16f, 16f, boxBgPaint)
                canvas.drawRoundRect(boxRect, 16f, 16f, boxStrokePaint)

                // كتابة اليوم والتاريخ بالتنسيق: [اليوم] [DD / MM / YYYY] بخط واضح وكبير
                val datePaint = Paint().apply {
                    color = Color.rgb(30, 40, 60)
                    textSize = 20f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    textAlign = Paint.Align.CENTER
                    isAntiAlias = true
                }
                canvas.drawText(dayDateText, pageWidth / 2, 380f, datePaint)

                // نص واضح ومميز أسفل التاريخ مباشرة: "لا توجد أحداث بالإدارة لهذا اليوم"
                val noIncidentsPaint = Paint().apply {
                    color = Color.rgb(13, 71, 161) // Dark Blue / Distinct
                    textSize = 24f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    textAlign = Paint.Align.CENTER
                    isAntiAlias = true
                }
                canvas.drawText("لا توجد أحداث بالإدارة لهذا اليوم", pageWidth / 2, 435f, noIncidentsPaint)

                val notePaint = Paint().apply {
                    color = Color.rgb(46, 125, 50) // Green
                    textSize = 12f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                    textAlign = Paint.Align.CENTER
                    isAntiAlias = true
                }
                canvas.drawText("الحالة الأمنية مستقرة تماماً بجميع مدارس الإدارة التعليمية", pageWidth / 2, 462f, notePaint)
            } else {
                // حالة وجود أحداث: عرض التاريخ وجدول الأحداث
                val subDatePaint = Paint().apply {
                    color = Color.rgb(30, 40, 60)
                    textSize = 15f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    textAlign = Paint.Align.RIGHT
                    isAntiAlias = true
                }
                canvas.drawText("بيان مكتب الأمن ليوم: $dayDateText (العدد: ${dayIncidents.size})", marginEnd, 145f, subDatePaint)

                var currentY = 175f
                val itemTitlePaint = Paint().apply {
                    color = Color.rgb(21, 101, 192)
                    textSize = 13f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    textAlign = Paint.Align.RIGHT
                    isAntiAlias = true
                }
                val itemBodyPaint = Paint().apply {
                    color = Color.rgb(50, 50, 50)
                    textSize = 11f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                    textAlign = Paint.Align.RIGHT
                    isAntiAlias = true
                }

                dayIncidents.take(8).forEachIndexed { index, incident ->
                    canvas.drawText("${index + 1}) ${incident.title} - مدرسة: ${incident.schoolName}", marginEnd, currentY, itemTitlePaint)
                    currentY += 18f
                    val details = "الحالة: ${incident.status.displayNameAr} | الأطراف: ${incident.partiesInvolved.ifBlank { "غير محدد" }} | الوقت: ${incident.timeString}"
                    canvas.drawText(details, marginEnd, currentY, itemBodyPaint)
                    currentY += 16f
                    if (incident.actionTaken.isNotBlank()) {
                        canvas.drawText("الإجراء: ${incident.actionTaken}", marginEnd, currentY, itemBodyPaint)
                        currentY += 16f
                    }
                    currentY += 10f
                }
            }

            // 3. التذييل والتوقيعات الرسمية في أسفل الصفحة:
            // - خط أفقي فاصل قبل التوقيعات
            val footerLineY = 730f
            canvas.drawLine(marginStart, footerLineY, marginEnd, footerLineY, footerLinePaint)

            // - جهة اليمين:
            // إعداد / مسئول الأمن
            // (اسم مسؤول الأمن المعتمد بالتطبيق)
            val sigTitlePaint = Paint().apply {
                color = Color.rgb(20, 30, 50)
                textSize = 13f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.RIGHT
                isAntiAlias = true
            }
            val sigNamePaint = Paint().apply {
                color = Color.rgb(21, 101, 192)
                textSize = 14f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.RIGHT
                isAntiAlias = true
            }

            canvas.drawText("إعداد / مسئول الأمن", marginEnd, footerLineY + 25f, sigTitlePaint)
            canvas.drawText(adminConfig.securityOfficerName, marginEnd, footerLineY + 50f, sigNamePaint)

            // - جهة اليسار:
            // يعتمد / مدير عام الإدارة
            val sigLeftTitlePaint = Paint().apply {
                color = Color.rgb(20, 30, 50)
                textSize = 13f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.LEFT
                isAntiAlias = true
            }
            val sigLeftNamePaint = Paint().apply {
                color = Color.rgb(21, 101, 192)
                textSize = 14f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.LEFT
                isAntiAlias = true
            }

            canvas.drawText("يعتمد / مدير عام الإدارة", marginStart, footerLineY + 25f, sigLeftTitlePaint)
            canvas.drawText(adminConfig.directorGeneralName, marginStart, footerLineY + 50f, sigLeftNamePaint)

            pdfDocument.finishPage(page)

            FileOutputStream(outFile).use { fos ->
                pdfDocument.writeTo(fos)
            }
            pdfDocument.close()
        } catch (e: Throwable) {
            // معالجة بيئات الاختبار الآلي / JVM التي لا يتوفر فيها محرك PdfDocument أصيل
            FileOutputStream(outFile).use { fos ->
                val fallbackPdf = buildFallbackPdfBytes(dayDateText, dayIncidents, adminConfig.securityOfficerName)
                fos.write(fallbackPdf)
            }
        }
        return outFile
    }

    fun generateDailyReportPdf(
        context: Context,
        date: Date,
        incidents: List<SecurityIncident>,
        supervisorName: String
    ): File = generateDailyReportPdf(context, date, incidents, AdminConfig(securityOfficerName = supervisorName))

    private fun buildFallbackPdfBytes(
        dayDateText: String,
        incidents: List<SecurityIncident>,
        supervisorName: String
    ): ByteArray {
        val streamContent = "BT /F1 12 Tf 50 750 Td (Security Clearance Report: $dayDateText - $supervisorName) Tj ET"
        val streamBytes = streamContent.toByteArray(StandardCharsets.UTF_8)
        val sb = StringBuilder()
        sb.append("%PDF-1.4\n")
        sb.append("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")
        sb.append("2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n")
        sb.append("3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R >>\nendobj\n")
        sb.append("4 0 obj\n<< /Length ${streamBytes.size} >>\nstream\n")
        sb.append(streamContent)
        sb.append("\nendstream\nendobj\n")
        sb.append("xref\n0 5\n0000000000 65535 f \n0000000009 00000 n \n0000000058 00000 n \n0000000115 00000 n \n0000000216 00000 n \n")
        sb.append("trailer\n<< /Size 5 /Root 1 0 R >>\nstartxref\n330\n%%EOF\n")
        return sb.toString().toByteArray(StandardCharsets.UTF_8)
    }

    /**
     * توليد ملف Word (DOCX) بتنسيق RTL كامل ودقيق.
     * يطبق شرط "تقرير خلو الأحداث" إذا لم تكن هناك أحداث مسجلة لهذا اليوم.
     */
    fun generateDailyReportDocx(
        context: Context,
        date: Date,
        incidents: List<SecurityIncident>,
        adminConfig: AdminConfig = AdminConfig()
    ): File {
        val dayIncidents = filterIncidentsByDate(incidents, date)
        val dayDateText = formatOfficialDayDate(date)

        val dateSlug = SimpleDateFormat("yyyy_MM_dd", Locale.US).format(date)
        val admSlug = adminConfig.administrationName.replace(" ", "_")
        val fileName = if (dayIncidents.isEmpty()) "إفادة_خلو_أحداث_${admSlug}_$dateSlug.docx" else "تقرير_أحداث_${admSlug}_$dateSlug.docx"
        val docxFile = File(context.cacheDir, fileName)

        val documentXml = buildDocxDocumentXml(dayDateText, dayIncidents, adminConfig)
        val contentTypesXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>"""

        val relsXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

        val docRelsXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

        val stylesXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:docDefaults>
    <w:rPrDefault>
      <w:rPr>
        <w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/>
        <w:sz w:val="24"/>
        <w:szCs w:val="24"/>
        <w:rtl/>
      </w:rPr>
    </w:rPrDefault>
    <w:pPrDefault>
      <w:pPr>
        <w:bidi/>
        <w:jc w:val="right"/>
      </w:pPr>
    </w:pPrDefault>
  </w:docDefaults>
</w:styles>"""

        ZipOutputStream(FileOutputStream(docxFile)).use { zos ->
            // [Content_Types].xml
            zos.putNextEntry(ZipEntry("[Content_Types].xml"))
            zos.write(contentTypesXml.toByteArray(StandardCharsets.UTF_8))
            zos.closeEntry()

            // _rels/.rels
            zos.putNextEntry(ZipEntry("_rels/.rels"))
            zos.write(relsXml.toByteArray(StandardCharsets.UTF_8))
            zos.closeEntry()

            // word/_rels/document.xml.rels
            zos.putNextEntry(ZipEntry("word/_rels/document.xml.rels"))
            zos.write(docRelsXml.toByteArray(StandardCharsets.UTF_8))
            zos.closeEntry()

            // word/styles.xml
            zos.putNextEntry(ZipEntry("word/styles.xml"))
            zos.write(stylesXml.toByteArray(StandardCharsets.UTF_8))
            zos.closeEntry()

            // word/document.xml
            zos.putNextEntry(ZipEntry("word/document.xml"))
            zos.write(documentXml.toByteArray(StandardCharsets.UTF_8))
            zos.closeEntry()
        }

        return docxFile
    }

    fun generateDailyReportDocx(
        context: Context,
        date: Date,
        incidents: List<SecurityIncident>,
        supervisorName: String
    ): File = generateDailyReportDocx(context, date, incidents, AdminConfig(securityOfficerName = supervisorName))

    private fun escapeXml(text: String): String {
        return text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }

    private fun buildDocxDocumentXml(
        dayDateText: String,
        incidents: List<SecurityIncident>,
        adminConfig: AdminConfig
    ): String {
        val sb = java.lang.StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">""")
        sb.append("<w:body>")

        // 1. الترويسة العلوية في جدول أفقي بدون حدود:
        // اليمين: المديرية - الإدارة
        // اليسار / المنتصف: عنوان رئيسي عريض "تقرير الأحداث اليومية للمدارس"
        sb.append("""
            <w:tbl>
              <w:tblPr>
                <w:tblW w:w="9600" w:type="dxa"/>
                <w:bidiVisual/>
                <w:tblBorders>
                  <w:top w:val="none"/>
                  <w:left w:val="none"/>
                  <w:bottom w:val="none"/>
                  <w:right w:val="none"/>
                  <w:insideH w:val="none"/>
                  <w:insideV w:val="none"/>
                </w:tblBorders>
              </w:tblPr>
              <w:tr>
                <w:tc>
                  <w:tcPr><w:tcW w:w="4800" w:type="dxa"/></w:tcPr>
                  <w:p>
                    <w:pPr><w:bidi/><w:jc w:val="right"/></w:pPr>
                    <w:r><w:rPr><w:b/><w:sz w:val="26"/><w:szCs w:val="26"/></w:rPr><w:t>${escapeXml(adminConfig.directorateName)}</w:t></w:r>
                  </w:p>
                  <w:p>
                    <w:pPr><w:bidi/><w:jc w:val="right"/></w:pPr>
                    <w:r><w:rPr><w:b/><w:sz w:val="26"/><w:szCs w:val="26"/></w:rPr><w:t>${escapeXml(adminConfig.administrationName)}</w:t></w:r>
                  </w:p>
                  <w:p>
                    <w:pPr><w:bidi/><w:jc w:val="right"/></w:pPr>
                    <w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/><w:color w:val="555555"/></w:rPr><w:t>مكتب الأمن</w:t></w:r>
                  </w:p>
                </w:tc>
                <w:tc>
                  <w:tcPr><w:tcW w:w="4800" w:type="dxa"/></w:tcPr>
                  <w:p>
                    <w:pPr><w:bidi/><w:jc w:val="center"/><w:spacing w:before="120"/></w:pPr>
                    <w:r>
                      <w:rPr><w:b/><w:sz w:val="34"/><w:szCs w:val="34"/><w:color w:val="1565C0"/></w:rPr>
                      <w:t>تقرير الأحداث اليومية للمدارس</w:t>
                    </w:r>
                  </w:p>
                </w:tc>
              </w:tr>
            </w:tbl>
        """.trimIndent())

        // خط فاصل أفقي أسفل الترويسة بعرض الصفحة
        sb.append("""
            <w:p>
              <w:pPr>
                <w:pBdr>
                  <w:bottom w:val="single" w:sz="18" w:space="8" w:color="1565C0"/>
                </w:pBdr>
                <w:spacing w:after="360"/>
              </w:pPr>
            </w:p>
        """.trimIndent())

        // 2. منتصف الصفحة:
        if (incidents.isEmpty()) {
            // حالة خلو الأحداث:
            // مسافات عمودية
            sb.append("""<w:p><w:pPr><w:spacing w:before="720"/></w:pPr></w:p>""")
            sb.append("""<w:p><w:pPr><w:spacing w:before="720"/></w:pPr></w:p>""")

            // كتابة اليوم والتاريخ بالتنسيق: [اليوم] [DD / MM / YYYY] بخط واضح وكبير
            sb.append("""
                <w:p>
                  <w:pPr>
                    <w:bidi/>
                    <w:jc w:val="center"/>
                    <w:spacing w:before="360" w:after="240"/>
                  </w:pPr>
                  <w:r>
                    <w:rPr>
                      <w:b/>
                      <w:sz w:val="38"/>
                      <w:szCs w:val="38"/>
                      <w:color w:val="222222"/>
                    </w:rPr>
                    <w:t>${escapeXml(dayDateText)}</w:t>
                  </w:r>
                </w:p>
            """.trimIndent())

            // نص واضح ومميز أسفل التاريخ مباشرة: "لا توجد أحداث بالإدارة لهذا اليوم"
            sb.append("""
                <w:p>
                  <w:pPr>
                    <w:bidi/>
                    <w:jc w:val="center"/>
                    <w:spacing w:before="240" w:after="360"/>
                  </w:pPr>
                  <w:r>
                    <w:rPr>
                      <w:b/>
                      <w:sz w:val="46"/>
                      <w:szCs w:val="46"/>
                      <w:color w:val="0D47A1"/>
                    </w:rPr>
                    <w:t>لا توجد أحداث بالإدارة لهذا اليوم</w:t>
                  </w:r>
                </w:p>
                <w:p>
                  <w:pPr>
                    <w:bidi/>
                    <w:jc w:val="center"/>
                    <w:spacing w:before="120" w:after="720"/>
                  </w:pPr>
                  <w:r>
                    <w:rPr>
                      <w:sz w:val="24"/>
                      <w:szCs w:val="24"/>
                      <w:color w:val="2E7D32"/>
                    </w:rPr>
                    <w:t>(إفادة رسمية باستقرار الحالة الأمنية العامة بمدارس إدارة سمالوط التعليمية)</w:t>
                  </w:r>
                </w:p>
            """.trimIndent())

            sb.append("""<w:p><w:pPr><w:spacing w:before="720"/></w:pPr></w:p>""")
            sb.append("""<w:p><w:pPr><w:spacing w:before="720"/></w:pPr></w:p>""")
        } else {
            // حالة وجود أحداث مسجلة: جدول رسمي للوقائع
            sb.append("""
                <w:p>
                  <w:pPr>
                    <w:bidi/>
                    <w:jc w:val="right"/>
                    <w:spacing w:before="180" w:after="180"/>
                  </w:pPr>
                  <w:r>
                    <w:rPr><w:b/><w:sz w:val="28"/><w:szCs w:val="28"/><w:color w:val="1565C0"/></w:rPr>
                    <w:t>بيان مكتب الأمن ليوم: ${escapeXml(dayDateText)}</w:t>
                  </w:r>
                </w:p>
            """.trimIndent())

            // جدول الأحداث
            sb.append("""
                <w:tbl>
                  <w:tblPr>
                    <w:tblW w:w="9600" w:type="dxa"/>
                    <w:bidiVisual/>
                    <w:tblBorders>
                      <w:top w:val="single" w:sz="6" w:color="1565C0"/>
                      <w:left w:val="single" w:sz="6" w:color="1565C0"/>
                      <w:bottom w:val="single" w:sz="6" w:color="1565C0"/>
                      <w:right w:val="single" w:sz="6" w:color="1565C0"/>
                      <w:insideH w:val="single" w:sz="4" w:color="CCCCCC"/>
                      <w:insideV w:val="single" w:sz="4" w:color="CCCCCC"/>
                    </w:tblBorders>
                  </w:tblPr>
                  <w:tr>
                    <w:tc><w:tcPr><w:tcW w:w="800" w:type="dxa"/><w:shd w:val="clear" w:color="auto" w:fill="1565C0"/></w:tcPr><w:p><w:pPr><w:bidi/><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>م</w:t></w:r></w:p></w:tc>
                    <w:tc><w:tcPr><w:tcW w:w="2600" w:type="dxa"/><w:shd w:val="clear" w:color="auto" w:fill="1565C0"/></w:tcPr><w:p><w:pPr><w:bidi/><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>موضوع الحدث</w:t></w:r></w:p></w:tc>
                    <w:tc><w:tcPr><w:tcW w:w="2400" w:type="dxa"/><w:shd w:val="clear" w:color="auto" w:fill="1565C0"/></w:tcPr><w:p><w:pPr><w:bidi/><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>المدرسة</w:t></w:r></w:p></w:tc>
                    <w:tc><w:tcPr><w:tcW w:w="1600" w:type="dxa"/><w:shd w:val="clear" w:color="auto" w:fill="1565C0"/></w:tcPr><w:p><w:pPr><w:bidi/><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>الحالة</w:t></w:r></w:p></w:tc>
                    <w:tc><w:tcPr><w:tcW w:w="2200" w:type="dxa"/><w:shd w:val="clear" w:color="auto" w:fill="1565C0"/></w:tcPr><w:p><w:pPr><w:bidi/><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr><w:t>الإجراء المتخذ</w:t></w:r></w:p></w:tc>
                  </w:tr>
            """.trimIndent())

            incidents.forEachIndexed { i, it ->
                sb.append("""
                  <w:tr>
                    <w:tc><w:tcPr><w:tcW w:w="800" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:bidi/><w:jc w:val="center"/></w:pPr><w:r><w:t>${i + 1}</w:t></w:r></w:p></w:tc>
                    <w:tc><w:tcPr><w:tcW w:w="2600" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:bidi/><w:jc w:val="right"/></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>${escapeXml(it.title)}</w:t></w:r></w:p></w:tc>
                    <w:tc><w:tcPr><w:tcW w:w="2400" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:bidi/><w:jc w:val="right"/></w:pPr><w:r><w:t>${escapeXml(it.schoolName)}</w:t></w:r></w:p></w:tc>
                    <w:tc><w:tcPr><w:tcW w:w="1600" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:bidi/><w:jc w:val="center"/></w:pPr><w:r><w:t>${escapeXml(it.status.displayNameAr)}</w:t></w:r></w:p></w:tc>
                    <w:tc><w:tcPr><w:tcW w:w="2200" w:type="dxa"/></w:tcPr><w:p><w:pPr><w:bidi/><w:jc w:val="right"/></w:pPr><w:r><w:t>${escapeXml(it.actionTaken.ifBlank { "متابعة أمنية مستمرة" })}</w:t></w:r></w:p></w:tc>
                  </w:tr>
                """.trimIndent())
            }

            sb.append("</w:tbl>")
        }

        // 3. التذييل والتوقيعات الرسمية في أسفل الصفحة:
        // - خط أفقي فاصل قبل التوقيعات
        sb.append("""
            <w:p>
              <w:pPr>
                <w:pBdr>
                  <w:bottom w:val="single" w:sz="14" w:space="8" w:color="1565C0"/>
                </w:pBdr>
                <w:spacing w:before="360" w:after="240"/>
              </w:pPr>
            </w:p>
        """.trimIndent())

        // التوقيعات (جدول ثنائي):
        // اليمين: إعداد / مسئول الأمن - اسم المسؤول
        // اليسار: يعتمد / مدير الإدارة - ...........................
        sb.append("""
            <w:tbl>
              <w:tblPr>
                <w:tblW w:w="9600" w:type="dxa"/>
                <w:bidiVisual/>
                <w:tblBorders>
                  <w:top w:val="none"/>
                  <w:left w:val="none"/>
                  <w:bottom w:val="none"/>
                  <w:right w:val="none"/>
                  <w:insideH w:val="none"/>
                  <w:insideV w:val="none"/>
                </w:tblBorders>
              </w:tblPr>
              <w:tr>
                <w:tc>
                  <w:tcPr><w:tcW w:w="4800" w:type="dxa"/></w:tcPr>
                  <w:p>
                    <w:pPr><w:bidi/><w:jc w:val="right"/></w:pPr>
                    <w:r><w:rPr><w:b/><w:sz w:val="28"/><w:szCs w:val="28"/></w:rPr><w:t>إعداد / مسئول الأمن</w:t></w:r>
                  </w:p>
                  <w:p>
                    <w:pPr><w:bidi/><w:jc w:val="right"/></w:pPr>
                    <w:r><w:rPr><w:b/><w:sz w:val="28"/><w:szCs w:val="28"/><w:color w:val="1565C0"/></w:rPr><w:t>${escapeXml(adminConfig.securityOfficerName)}</w:t></w:r>
                  </w:p>
                </w:tc>
                <w:tc>
                  <w:tcPr><w:tcW w:w="4800" w:type="dxa"/></w:tcPr>
                  <w:p>
                    <w:pPr><w:bidi/><w:jc w:val="left"/></w:pPr>
                    <w:r><w:rPr><w:b/><w:sz w:val="28"/><w:szCs w:val="28"/></w:rPr><w:t>يعتمد / مدير عام الإدارة</w:t></w:r>
                  </w:p>
                  <w:p>
                    <w:pPr><w:bidi/><w:jc w:val="left"/></w:pPr>
                    <w:r><w:rPr><w:b/><w:sz w:val="28"/><w:szCs w:val="28"/><w:color w:val="1565C0"/></w:rPr><w:t>${escapeXml(adminConfig.directorGeneralName)}</w:t></w:r>
                  </w:p>
                </w:tc>
              </w:tr>
            </w:tbl>
        """.trimIndent())

        sb.append("</w:body></w:document>")
        return sb.toString()
    }

    /**
     * مشاركة أي ملف (PDF أو DOCX) عبر Intent بنظام مشاركة الملفات الآمن
     */
    fun shareGeneratedFile(context: Context, file: File, mimeType: String, title: String) {
        try {
            val authority = "${context.packageName}.fileprovider"
            val uri = FileProvider.getUriForFile(context, authority, file)

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, title)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, title))
        } catch (e: Exception) {
            Toast.makeText(context, "تعذر مشاركة الملف: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * طباعة مستند PDF أو عرضه عبر WebView PrintManager
     * يطبق شرط تقرير خلو الأحداث
     */
    fun exportToPdfPrint(
        context: Context,
        period: ReportPeriod,
        incidents: List<SecurityIncident>,
        adminConfig: AdminConfig = AdminConfig(),
        selectedDate: Date = Date()
    ) {
        val filtered = if (period == ReportPeriod.DAILY) {
            filterIncidentsByDate(incidents, selectedDate)
        } else {
            incidents
        }

        val dayDateText = formatOfficialDayDate(selectedDate)
        val html = buildHtmlReport(period, filtered, adminConfig, dayDateText)

        val webView = WebView(context)
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
                val docName = if (filtered.isEmpty()) "إفادة_خلو_أحداث" else "تقرير_أمن_${period.name}"
                val printAdapter = webView.createPrintDocumentAdapter(docName)
                val jobName = if (filtered.isEmpty()) "إفادة خلو أحداث - $dayDateText" else "تقرير أمن - ${period.titleAr}"
                printManager?.print(jobName, printAdapter, PrintAttributes.Builder().build())
            }
        }
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }

    fun exportToPdfPrint(
        context: Context,
        period: ReportPeriod,
        incidents: List<SecurityIncident>,
        supervisorName: String,
        selectedDate: Date = Date()
    ) = exportToPdfPrint(context, period, incidents, AdminConfig(securityOfficerName = supervisorName), selectedDate)

    private fun buildHtmlReport(
        period: ReportPeriod,
        incidents: List<SecurityIncident>,
        adminConfig: AdminConfig,
        dayDateText: String
    ): String {
        val isEmptyReport = incidents.isEmpty()

        val mainContent = if (isEmptyReport) {
            """
            <div style="margin: 120px 0; text-align: center; border: 2px dashed #1565C0; background-color: #F4F8FB; padding: 40px; border-radius: 12px;">
                <h2 style="font-size: 26px; color: #222; margin-bottom: 20px;">$dayDateText</h2>
                <h1 style="font-size: 32px; color: #0D47A1; margin: 0; font-weight: bold;">لا توجد أحداث بالإدارة لهذا اليوم</h1>
                <p style="color: #2E7D32; font-size: 16px; margin-top: 15px;">الحالة الأمنية مستقرة تماماً بجميع مدارس إدارة سمالوط التعليمية</p>
            </div>
            """.trimIndent()
        } else {
            val rows = StringBuilder()
            incidents.forEachIndexed { i, it ->
                val bg = when (it.status) {
                    IncidentStatus.RESOLVED -> "#E8F5E9"
                    IncidentStatus.IN_PROGRESS -> "#FFF8E1"
                    IncidentStatus.CLOSED -> "#ECEFF1"
                }
                rows.append("""
                    <tr style="background-color: $bg;">
                        <td style="padding: 10px; border: 1px solid #ccc; text-align: center;">${i + 1}</td>
                        <td style="padding: 10px; border: 1px solid #ccc; font-weight: bold;">${it.title}</td>
                        <td style="padding: 10px; border: 1px solid #ccc;">${it.schoolName}</td>
                        <td style="padding: 10px; border: 1px solid #ccc; text-align: center;">${it.status.displayNameAr}</td>
                        <td style="padding: 10px; border: 1px solid #ccc;">${it.partiesInvolved.ifBlank { "—" }}</td>
                        <td style="padding: 10px; border: 1px solid #ccc;">${it.actionTaken.ifBlank { "متابعة دورية" }}</td>
                        <td style="padding: 10px; border: 1px solid #ccc; text-align: center;">${it.timeString}</td>
                    </tr>
                """.trimIndent())
            }

            """
            <h3 style="color: #1565C0; margin-top: 25px;">بيان مكتب الأمن ليوم: $dayDateText</h3>
            <table style="width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 13px;">
                <thead>
                    <tr style="background-color: #1565C0; color: white;">
                        <th style="padding: 10px; border: 1px solid #ccc;">م</th>
                        <th style="padding: 10px; border: 1px solid #ccc;">موضوع الحدث</th>
                        <th style="padding: 10px; border: 1px solid #ccc;">المدرسة</th>
                        <th style="padding: 10px; border: 1px solid #ccc;">الحالة</th>
                        <th style="padding: 10px; border: 1px solid #ccc;">الأطراف</th>
                        <th style="padding: 10px; border: 1px solid #ccc;">الإجراء المتخذ</th>
                        <th style="padding: 10px; border: 1px solid #ccc;">الوقت</th>
                    </tr>
                </thead>
                <tbody>
                    $rows
                </tbody>
            </table>
            """.trimIndent()
        }

        return """
            <!DOCTYPE html>
            <html dir="rtl" lang="ar">
            <head>
                <meta charset="utf-8">
                <title>تقرير أمن سمالوط</title>
                <style>
                    body { font-family: 'Segoe UI', Tahoma, Arial, sans-serif; padding: 30px; direction: rtl; text-align: right; }
                    .header-tbl { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
                    .header-tbl td { vertical-align: middle; border: none; }
                    .divider { border-bottom: 2px solid #1565C0; margin: 15px 0 25px 0; }
                    .footer-tbl { width: 100%; border-collapse: collapse; margin-top: 40px; }
                    .footer-tbl td { vertical-align: top; border: none; font-size: 15px; font-weight: bold; }
                </style>
            </head>
            <body>
                <table class="header-tbl">
                    <tr>
                        <td style="text-align: right; width: 45%;">
                            <h3 style="margin: 0; color: #111;">${adminConfig.directorateName}</h3>
                            <h3 style="margin: 4px 0; color: #111;">${adminConfig.administrationName}</h3>
                            <p style="margin: 4px 0; color: #666; font-size: 13px;">مكتب الأمن</p>
                        </td>
                        <td style="text-align: center; width: 55%;">
                            <h2 style="color: #1565C0; margin: 0; font-size: 24px;">تقرير الأحداث اليومية للمدارس</h2>
                        </td>
                    </tr>
                </table>
                
                <div class="divider"></div>

                $mainContent

                <div class="divider" style="margin-top: 50px;"></div>

                <table class="footer-tbl">
                    <tr>
                        <td style="text-align: right; width: 50%;">
                            <p style="margin: 0 0 8px 0;">إعداد / مسئول الأمن</p>
                            <p style="margin: 0; color: #1565C0; font-size: 16px;">${adminConfig.securityOfficerName}</p>
                        </td>
                        <td style="text-align: left; width: 50%;">
                            <p style="margin: 0 0 8px 0;">يعتمد / مدير عام الإدارة</p>
                            <p style="margin: 0; color: #1565C0; font-size: 16px;">${adminConfig.directorGeneralName}</p>
                        </td>
                    </tr>
                </table>
            </body>
            </html>
        """.trimIndent()
    }

    /**
     * نص التقرير للمشاركة السريعة ونسخ الحافظة
     */
    fun generateReportText(
        period: ReportPeriod,
        incidents: List<SecurityIncident>,
        adminConfig: AdminConfig = AdminConfig(),
        selectedDate: Date = Date()
    ): String {
        val filtered = if (period == ReportPeriod.DAILY) {
            filterIncidentsByDate(incidents, selectedDate)
        } else {
            incidents
        }

        val dayDateText = formatOfficialDayDate(selectedDate)
        val sb = StringBuilder()

        sb.append("📋 *${adminConfig.administrationName}*\n")
        sb.append("${adminConfig.directorateName} | ${adminConfig.administrationName}\n")
        sb.append("══════════════════════════\n")
        sb.append("📌 *تقرير الأحداث اليومية للمدارس*\n")
        sb.append("📅 *اليوم والتاريخ:* $dayDateText\n")
        sb.append("══════════════════════════\n\n")

        if (filtered.isEmpty()) {
            sb.append("✨ *لا توجد أحداث بالإدارة لهذا اليوم*\n\n")
            sb.append("• الحالة الأمنية مستقرة تماماً بجميع مدارس ${adminConfig.administrationName} بفضل الله.\n\n")
        } else {
            sb.append("📊 *بيان مكتب الأمن (${filtered.size}):*\n\n")
            filtered.forEachIndexed { index, item ->
                sb.append("${index + 1}) *${item.title}*\n")
                sb.append("   - المدرسة: ${item.schoolName}\n")
                sb.append("   - الحالة: ${item.status.displayNameAr}\n")
                if (item.partiesInvolved.isNotBlank()) {
                    sb.append("   - الأطراف: ${item.partiesInvolved}\n")
                }
                if (item.actionTaken.isNotBlank()) {
                    sb.append("   - الإجراء: ${item.actionTaken}\n")
                }
                sb.append("   - الوقت: ${item.timeString}\n\n")
            }
        }

        sb.append("══════════════════════════\n")
        sb.append("إعداد / مسئول الأمن: ${adminConfig.securityOfficerName}\n")
        sb.append("يعتمد / مدير عام الإدارة: ${adminConfig.directorGeneralName}")

        return sb.toString()
    }

    fun generateReportText(
        period: ReportPeriod,
        incidents: List<SecurityIncident>,
        supervisorName: String,
        selectedDate: Date = Date()
    ): String = generateReportText(period, incidents, AdminConfig(securityOfficerName = supervisorName), selectedDate)

    fun exportIncidentsToCsv(incidents: List<SecurityIncident>): String {
        val sb = StringBuilder()
        sb.append("م,العنوان,المدرسة,الحالة,الأطراف,الإجراء,التاريخ,الوقت\n")
        incidents.forEachIndexed { i, it ->
            sb.append("${i + 1},\"${it.title}\",\"${it.schoolName}\",\"${it.status.displayNameAr}\",\"${it.partiesInvolved}\",\"${it.actionTaken}\",\"${it.dateString}\",\"${it.timeString}\"\n")
        }
        return sb.toString()
    }

    fun shareCsvToExternal(context: Context, csvText: String, filename: String = "تقرير_أمن_سمالوط.csv") {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_SUBJECT, filename)
            putExtra(Intent.EXTRA_TEXT, csvText)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(Intent.createChooser(intent, "تصدير ملف Excel / CSV"))
        } catch (e: Exception) {
            Toast.makeText(context, "تعذر مشاركة الملف", Toast.LENGTH_SHORT).show()
        }
    }
}
