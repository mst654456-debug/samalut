package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.populateInitialData
import com.example.data.model.DailyLogEntry
import com.example.data.model.EventEntity
import com.example.data.model.IncidentStatus
import com.example.data.model.School
import com.example.data.model.SchoolEntity
import com.example.data.model.SchoolStage
import com.example.data.model.SecurityIncident
import com.example.data.model.Teacher
import com.example.data.preferences.AdminConfig
import com.example.data.preferences.AdminPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SecurityRepository(
    private val database: AppDatabase,
    private val adminPreferences: AdminPreferences? = null
) {

    private val schoolDao = database.schoolDao()
    private val teacherDao = database.teacherDao()
    private val incidentDao = database.securityIncidentDao()
    private val dailyLogDao = database.dailyLogDao()
    private val teacherLeaveDao = database.teacherLeaveDao()
    private val teacherPenaltyDao = database.teacherPenaltyDao()
    private val schoolTripDao = database.schoolTripDao()

    // Admin Preferences
    val adminConfig: StateFlow<AdminConfig> = adminPreferences?.adminConfig 
        ?: MutableStateFlow(AdminConfig()).asStateFlow()

    fun saveAdminConfig(
        directorate: String,
        administration: String,
        directorGeneral: String,
        securityOfficer: String
    ) {
        adminPreferences?.saveConfig(
            directorate = directorate,
            administration = administration,
            directorGeneral = directorGeneral,
            securityOfficer = securityOfficer,
            isCompleted = true
        )
    }

    fun setSetupCompleted(completed: Boolean) {
        adminPreferences?.setSetupCompleted(completed)
    }

    // Schools (SchoolEntity)
    val allSchools: Flow<List<School>> = schoolDao.getAllSchools()
    fun getSchoolsByStage(stage: SchoolStage): Flow<List<School>> = schoolDao.getSchoolsByStage(stage)
    suspend fun getSchoolById(id: Long): School? = schoolDao.getSchoolById(id)
    suspend fun insertSchool(school: School): Long = schoolDao.insertSchool(school)
    suspend fun insertSchools(schools: List<School>) = schoolDao.insertSchools(schools)
    suspend fun updateSchool(school: School) = schoolDao.updateSchool(school)
    suspend fun deleteSchool(school: School) = schoolDao.deleteSchool(school)
    suspend fun deleteSchoolById(id: Long) = schoolDao.deleteSchoolById(id)

    // Teachers
    val allTeachers: Flow<List<Teacher>> = teacherDao.getAllTeachers()
    fun getTeachersBySchool(schoolName: String): Flow<List<Teacher>> = teacherDao.getTeachersBySchool(schoolName)
    fun getTeachersByStage(stage: SchoolStage): Flow<List<Teacher>> = teacherDao.getTeachersByStage(stage)
    suspend fun getTeacherById(id: Long): Teacher? = teacherDao.getTeacherById(id)
    suspend fun insertTeacher(teacher: Teacher): Long = teacherDao.insertTeacher(teacher)
    suspend fun insertTeachers(teachers: List<Teacher>) = teacherDao.insertTeachers(teachers)
    suspend fun updateTeacher(teacher: Teacher) = teacherDao.updateTeacher(teacher)
    suspend fun deleteTeacher(teacher: Teacher) = teacherDao.deleteTeacher(teacher)
    suspend fun deleteTeacherById(id: Long) = teacherDao.deleteTeacherById(id)

    // Events / Incidents (EventEntity)
    val allIncidents: Flow<List<SecurityIncident>> = incidentDao.getAllIncidents()
    fun getIncidentsBySchool(schoolName: String): Flow<List<SecurityIncident>> = incidentDao.getIncidentsBySchool(schoolName)
    fun getIncidentsByStatus(status: IncidentStatus): Flow<List<SecurityIncident>> = incidentDao.getIncidentsByStatus(status)
    fun getIncidentsByParty(name: String): Flow<List<SecurityIncident>> = incidentDao.getIncidentsByParty(name)
    suspend fun getIncidentById(id: Long): SecurityIncident? = incidentDao.getIncidentById(id)
    suspend fun insertIncident(incident: SecurityIncident): Long = incidentDao.insertIncident(incident)
    suspend fun updateIncident(incident: SecurityIncident) = incidentDao.updateIncident(incident)
    suspend fun deleteIncident(incident: SecurityIncident) = incidentDao.deleteIncident(incident)
    suspend fun deleteIncidentById(id: Long) = incidentDao.deleteIncidentById(id)

    // Daily Logs
    val allLogs: Flow<List<DailyLogEntry>> = dailyLogDao.getAllLogs()
    fun getLogsBySchool(schoolName: String): Flow<List<DailyLogEntry>> = dailyLogDao.getLogsBySchool(schoolName)
    fun getLogsByTeacher(teacherName: String): Flow<List<DailyLogEntry>> = dailyLogDao.getLogsByTeacher(teacherName)
    suspend fun insertDailyLog(log: DailyLogEntry): Long = dailyLogDao.insertLog(log)
    suspend fun updateDailyLog(log: DailyLogEntry) = dailyLogDao.updateLog(log)
    suspend fun deleteDailyLog(log: DailyLogEntry) = dailyLogDao.deleteLog(log)

    // Teacher Leaves (سجل إجازات المعلمين)
    val allLeaves: Flow<List<com.example.data.model.TeacherLeaveEntity>> = teacherLeaveDao.getAllLeaves()
    fun getLeavesByTeacherId(teacherId: Long): Flow<List<com.example.data.model.TeacherLeaveEntity>> = teacherLeaveDao.getLeavesByTeacherId(teacherId)
    fun getLeavesByTeacherName(name: String): Flow<List<com.example.data.model.TeacherLeaveEntity>> = teacherLeaveDao.getLeavesByTeacherName(name)
    fun getLeavesBySchool(schoolName: String): Flow<List<com.example.data.model.TeacherLeaveEntity>> = teacherLeaveDao.getLeavesBySchool(schoolName)
    suspend fun insertLeave(leave: com.example.data.model.TeacherLeaveEntity): Long = teacherLeaveDao.insertLeave(leave)
    suspend fun updateLeave(leave: com.example.data.model.TeacherLeaveEntity) = teacherLeaveDao.updateLeave(leave)
    suspend fun deleteLeave(leave: com.example.data.model.TeacherLeaveEntity) = teacherLeaveDao.deleteLeave(leave)
    suspend fun deleteLeaveById(id: Long) = teacherLeaveDao.deleteLeaveById(id)

    // Teacher Penalties (سجل الجزاءات والخصومات)
    val allPenalties: Flow<List<com.example.data.model.TeacherPenaltyEntity>> = teacherPenaltyDao.getAllPenalties()
    fun getPenaltiesByTeacherId(teacherId: Long): Flow<List<com.example.data.model.TeacherPenaltyEntity>> = teacherPenaltyDao.getPenaltiesByTeacherId(teacherId)
    fun getPenaltiesByTeacherName(name: String): Flow<List<com.example.data.model.TeacherPenaltyEntity>> = teacherPenaltyDao.getPenaltiesByTeacherName(name)
    suspend fun insertPenalty(penalty: com.example.data.model.TeacherPenaltyEntity): Long = teacherPenaltyDao.insertPenalty(penalty)
    suspend fun updatePenalty(penalty: com.example.data.model.TeacherPenaltyEntity) = teacherPenaltyDao.updatePenalty(penalty)
    suspend fun deletePenalty(penalty: com.example.data.model.TeacherPenaltyEntity) = teacherPenaltyDao.deletePenalty(penalty)
    suspend fun deletePenaltyById(id: Long) = teacherPenaltyDao.deletePenaltyById(id)

    // School Trips (رحلات وأنشطة المدرسة)
    val allTrips: Flow<List<com.example.data.model.SchoolTripEntity>> = schoolTripDao.getAllTrips()
    fun getTripsBySchool(schoolName: String): Flow<List<com.example.data.model.SchoolTripEntity>> = schoolTripDao.getTripsBySchool(schoolName)
    fun getTripsBySchoolId(schoolId: Long): Flow<List<com.example.data.model.SchoolTripEntity>> = schoolTripDao.getTripsBySchoolId(schoolId)
    suspend fun insertTrip(trip: com.example.data.model.SchoolTripEntity): Long = schoolTripDao.insertTrip(trip)
    suspend fun updateTrip(trip: com.example.data.model.SchoolTripEntity) = schoolTripDao.updateTrip(trip)
    suspend fun deleteTrip(trip: com.example.data.model.SchoolTripEntity) = schoolTripDao.deleteTrip(trip)
    suspend fun deleteTripById(id: Long) = schoolTripDao.deleteTripById(id)

    // Reset Data
    suspend fun resetAllData() {
        database.clearAllTables()
        populateInitialData(database)
    }

    // Excel / CSV Importer with Duplicate Code Avoidance
    suspend fun importSchoolsList(schools: List<School>): ImportSummary {
        var added = 0
        var updated = 0
        val errors = mutableListOf<String>()

        for (school in schools) {
            try {
                val existing = if (school.code.isNotBlank()) {
                    schoolDao.getSchoolByCode(school.code) ?: schoolDao.getSchoolByName(school.name)
                } else {
                    schoolDao.getSchoolByName(school.name)
                }

                if (existing != null) {
                    schoolDao.updateSchool(
                        school.copy(
                            id = existing.id,
                            governorate = if (school.governorate.isNotBlank()) school.governorate else existing.governorate,
                            administration = if (school.administration.isNotBlank()) school.administration else existing.administration,
                            attachedFiles = if (school.attachedFiles.isEmpty()) existing.attachedFiles else school.attachedFiles
                        )
                    )
                    updated++
                } else {
                    schoolDao.insertSchool(school)
                    added++
                }
            } catch (e: Exception) {
                errors.add("خطأ في مدرسة ${school.name}: ${e.localizedMessage}")
            }
        }

        val msg = if (added > 0 || updated > 0) {
            "تمت إضافة $added مدرسة جديدة وتحديث $updated مدرسة مسجلة بنجاح."
        } else {
            "لم يتم استيراد أي مدارس جديدة."
        }

        return ImportSummary(
            totalProcessed = schools.size,
            addedCount = added,
            updatedCount = updated,
            errorsCount = errors.size,
            errors = errors,
            message = msg
        )
    }

    suspend fun importTeachersList(teachers: List<Teacher>): ImportSummary {
        var added = 0
        var updated = 0
        val errors = mutableListOf<String>()

        for (teacher in teachers) {
            try {
                val existing = if (teacher.teacherCode.isNotBlank()) {
                    teacherDao.getTeacherByCode(teacher.teacherCode)
                } else if (teacher.nationalId.isNotBlank()) {
                    teacherDao.getTeacherByNationalId(teacher.nationalId)
                } else {
                    null
                }

                val school = schoolDao.getSchoolByName(teacher.schoolName)
                val stage = school?.stage ?: teacher.stage
                val finalTeacher = teacher.copy(stage = stage)

                if (existing != null) {
                    teacherDao.updateTeacher(
                        finalTeacher.copy(
                            id = existing.id,
                            attachedFiles = if (teacher.attachedFiles.isEmpty()) existing.attachedFiles else teacher.attachedFiles
                        )
                    )
                    updated++
                } else {
                    teacherDao.insertTeacher(finalTeacher)
                    added++
                }
            } catch (e: Exception) {
                errors.add("خطأ في المعلم ${teacher.name}: ${e.localizedMessage}")
            }
        }

        val msg = if (added > 0 || updated > 0) {
            "تمت إضافة $added معلم/موظف جديد وتحديث $updated سجل معتمد بنجاح."
        } else {
            "لم يتم استيراد أي معلمين."
        }

        return ImportSummary(
            totalProcessed = teachers.size,
            addedCount = added,
            updatedCount = updated,
            errorsCount = errors.size,
            errors = errors,
            message = msg
        )
    }

    // Backup & Restore
    suspend fun createBackup(context: android.content.Context): com.example.util.BackupResult {
        return com.example.util.BackupManager.createFullBackup(context, database, adminPreferences)
    }

    suspend fun restoreBackup(context: android.content.Context, zipUriOrFile: Any): com.example.util.RestoreResult {
        return com.example.util.BackupManager.restoreFromBackup(context, zipUriOrFile, database, adminPreferences)
    }
}

data class ImportSummary(
    val totalProcessed: Int,
    val addedCount: Int,
    val updatedCount: Int,
    val errorsCount: Int,
    val errors: List<String> = emptyList(),
    val message: String
)
