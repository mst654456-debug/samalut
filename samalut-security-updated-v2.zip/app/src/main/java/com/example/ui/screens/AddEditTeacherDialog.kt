package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.School
import com.example.data.model.SchoolStage
import com.example.data.model.Teacher
import com.example.ui.theme.EduBlue
import com.example.ui.theme.EduGreen
import com.example.util.AttachmentHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditTeacherDialog(
    teacherToEdit: Teacher? = null,
    schoolsList: List<School> = emptyList(),
    onDismiss: () -> Unit,
    onSaveTeacher: (Teacher) -> Unit
) {
    val context = LocalContext.current
    val isEditMode = teacherToEdit != null

    var name by remember { mutableStateOf(teacherToEdit?.name ?: "") }
    var teacherCode by remember { mutableStateOf(teacherToEdit?.teacherCode ?: "") }
    var nationalId by remember { mutableStateOf(teacherToEdit?.nationalId ?: "") }
    var schoolName by remember { mutableStateOf(teacherToEdit?.schoolName ?: schoolsList.firstOrNull()?.name ?: "") }
    var selectedStage by remember { mutableStateOf(teacherToEdit?.stage ?: SchoolStage.PRIMARY) }
    var jobTitle by remember { mutableStateOf(teacherToEdit?.jobTitle ?: "معلم") }
    var assignedDuty by remember { mutableStateOf(teacherToEdit?.assignedDuty ?: "") }
    var phone by remember { mutableStateOf(teacherToEdit?.phone ?: "") }
    var subject by remember { mutableStateOf(teacherToEdit?.subject ?: "") }
    var address by remember { mutableStateOf(teacherToEdit?.address ?: "") }
    var hireDate by remember { mutableStateOf(teacherToEdit?.hireDate ?: "") }
    var notes by remember { mutableStateOf(teacherToEdit?.notes ?: "") }

    val attachedFiles = remember {
        mutableStateListOf<String>().apply {
            if (teacherToEdit != null) {
                addAll(teacherToEdit.attachedFiles)
            }
        }
    }

    var isSchoolMenuExpanded by remember { mutableStateOf(false) }
    var isStageMenuExpanded by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Pickers
    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        uris.forEach { uri ->
            val savedPath = AttachmentHelper.saveUriToInternalStorage(context, uri, prefix = "teacher_doc")
            if (savedPath != null && !attachedFiles.contains(savedPath)) {
                attachedFiles.add(savedPath)
            }
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris: List<Uri> ->
        uris.forEach { uri ->
            val savedPath = AttachmentHelper.saveUriToInternalStorage(context, uri, prefix = "teacher_img")
            if (savedPath != null && !attachedFiles.contains(savedPath)) {
                attachedFiles.add(savedPath)
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.94f)
                .testTag("dialog_add_edit_teacher"),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Title Bar
                Surface(
                    color = EduBlue,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isEditMode) Icons.Default.PersonSearch else Icons.Default.PersonAdd,
                                contentDescription = null,
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (isEditMode) "تعديل بيانات المعلم / الموظف" else "إضافة معلم / موظف جديد",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.White)
                        }
                    }
                }

                // Scrollable Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (errorMessage != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = errorMessage ?: "",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    // Section 1: Basic & Identification
                    Text(
                        text = "١. البيانات الأساسية والتعريفية",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = EduBlue
                    )

                    OutlinedTextField(
                        value = name,
                        onValueChange = {
                            name = it
                            errorMessage = null
                        },
                        label = { Text("اسم المعلم / الموظف *") },
                        placeholder = { Text("مثال: أ/ أحمد محمد علي") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = EduBlue) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("teacher_input_name"),
                        singleLine = true
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = teacherCode,
                            onValueChange = { teacherCode = it },
                            label = { Text("كود المعلم") },
                            placeholder = { Text("مثال: T-2041") },
                            leadingIcon = { Icon(Icons.Default.QrCode, contentDescription = null, tint = EduBlue) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("teacher_input_code"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = nationalId,
                            onValueChange = { nationalId = it.filter { ch -> ch.isDigit() } },
                            label = { Text("الرقم القومي (14 رقم)") },
                            placeholder = { Text("الرقم القومي") },
                            leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null, tint = EduBlue) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("teacher_input_national_id"),
                            singleLine = true
                        )
                    }

                    // School Selection Dropdown
                    ExposedDropdownMenuBox(
                        expanded = isSchoolMenuExpanded,
                        onExpandedChange = { isSchoolMenuExpanded = !isSchoolMenuExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = schoolName,
                            onValueChange = { schoolName = it },
                            label = { Text("المدرسة التابع لها *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isSchoolMenuExpanded) },
                            leadingIcon = { Icon(Icons.Default.School, contentDescription = null, tint = EduBlue) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                                .testTag("teacher_input_school")
                        )
                        if (schoolsList.isNotEmpty()) {
                            ExposedDropdownMenu(
                                expanded = isSchoolMenuExpanded,
                                onDismissRequest = { isSchoolMenuExpanded = false }
                            ) {
                                schoolsList.forEach { sch ->
                                    DropdownMenuItem(
                                        text = { Text(sch.name) },
                                        onClick = {
                                            schoolName = sch.name
                                            selectedStage = sch.stage
                                            isSchoolMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Stage Selection Dropdown
                    ExposedDropdownMenuBox(
                        expanded = isStageMenuExpanded,
                        onExpandedChange = { isStageMenuExpanded = !isStageMenuExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = selectedStage.displayNameAr,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("المرحلة التعليمية *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isStageMenuExpanded) },
                            leadingIcon = { Icon(Icons.Default.Category, contentDescription = null, tint = EduBlue) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = isStageMenuExpanded,
                            onDismissRequest = { isStageMenuExpanded = false }
                        ) {
                            SchoolStage.values().forEach { st ->
                                DropdownMenuItem(
                                    text = { Text(st.displayNameAr) },
                                    onClick = {
                                        selectedStage = st
                                        isStageMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    // Section 2: Job & Duty Assignment
                    Text(
                        text = "٢. الوظيفة والتكليف ومسؤوليات المدرسة",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = EduBlue
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = jobTitle,
                            onValueChange = { jobTitle = it },
                            label = { Text("الوظيفة الحالية") },
                            placeholder = { Text("مثال: معلم أول أ") },
                            leadingIcon = { Icon(Icons.Default.Work, contentDescription = null, tint = EduBlue) },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = subject,
                            onValueChange = { subject = it },
                            label = { Text("المادة / التخصص") },
                            placeholder = { Text("مثال: لغة عربية") },
                            leadingIcon = { Icon(Icons.Default.MenuBook, contentDescription = null, tint = EduBlue) },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    OutlinedTextField(
                        value = assignedDuty,
                        onValueChange = { assignedDuty = it },
                        label = { Text("العمل المكلف به داخل المدرسة") },
                        placeholder = { Text("مثال: مشرف عام الفناء / مسؤول الأمن والسلامة / تنظيم الدخول") },
                        leadingIcon = { Icon(Icons.Default.AssignmentInd, contentDescription = null, tint = EduGreen) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("teacher_input_duty"),
                        singleLine = true
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("رقم التليفون") },
                            placeholder = { Text("مثال: 01012345678") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = EduBlue) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("teacher_input_phone"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = hireDate,
                            onValueChange = { hireDate = it },
                            label = { Text("تاريخ التعيين") },
                            placeholder = { Text("YYYY/MM/DD") },
                            leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null, tint = EduBlue) },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("العنوان ومحل الإقامة") },
                        leadingIcon = { Icon(Icons.Default.Home, contentDescription = null, tint = EduBlue) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    // Section 3: Notes & Attached Files (Photos / PDFs)
                    Text(
                        text = "٣. الملاحظات وإرفاق المستندات والصور (PDF)",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = EduBlue
                    )

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("ملاحظات خاصة بالمعلم") },
                        placeholder = { Text("اكتب أي ملاحظات إدارية أو أمنية...") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        maxLines = 5,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Attached Files Box
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "المستندات والملفات المرفقة (${attachedFiles.size})",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilledTonalButton(
                                        onClick = {
                                            documentPickerLauncher.launch(arrayOf("application/pdf", "*/*"))
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.testTag("btn_attach_teacher_pdf")
                                    ) {
                                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("PDF / مستند", style = MaterialTheme.typography.labelSmall)
                                    }

                                    FilledTonalButton(
                                        onClick = {
                                            photoPickerLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.testTag("btn_attach_teacher_photo")
                                    ) {
                                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("صورة", style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }

                            if (attachedFiles.isEmpty()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "لا توجد مستندات أو صور مرفقة حالياً",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                Spacer(modifier = Modifier.height(10.dp))
                                attachedFiles.forEachIndexed { index, path ->
                                    val isPdf = AttachmentHelper.isPdf(path)
                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        color = MaterialTheme.colorScheme.surface
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 10.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clickable { AttachmentHelper.openAttachment(context, path) }
                                            ) {
                                                Icon(
                                                    imageVector = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.Image,
                                                    contentDescription = null,
                                                    tint = if (isPdf) Color(0xFFD32F2F) else EduBlue,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = AttachmentHelper.getDisplayName(path),
                                                    style = MaterialTheme.typography.bodySmall,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }

                                            IconButton(
                                                onClick = { attachedFiles.removeAt(index) },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Close,
                                                    contentDescription = "حذف المرفق",
                                                    tint = MaterialTheme.colorScheme.error,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Footer Actions
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 4.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("إلغاء")
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Button(
                            onClick = {
                                if (name.trim().isBlank()) {
                                    errorMessage = "يرجى كتابة اسم المعلم / الموظف"
                                    return@Button
                                }
                                if (schoolName.trim().isBlank()) {
                                    errorMessage = "يرجى اختيار أو تحديد المدرسة"
                                    return@Button
                                }

                                val newTeacher = Teacher(
                                    id = teacherToEdit?.id ?: 0L,
                                    name = name.trim(),
                                    teacherCode = teacherCode.trim(),
                                    nationalId = nationalId.trim(),
                                    schoolName = schoolName.trim(),
                                    stage = selectedStage,
                                    jobTitle = jobTitle.trim().ifBlank { "معلم" },
                                    assignedDuty = assignedDuty.trim(),
                                    phone = phone.trim(),
                                    address = address.trim(),
                                    subject = subject.trim(),
                                    hireDate = hireDate.trim(),
                                    notes = notes.trim(),
                                    attachedFiles = attachedFiles.toList()
                                )

                                onSaveTeacher(newTeacher)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EduGreen),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("btn_save_teacher")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isEditMode) "حفظ التعديلات" else "إضافة المعلم",
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
