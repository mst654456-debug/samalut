package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.IncidentStatus
import com.example.data.model.School
import com.example.data.model.SchoolStage
import com.example.data.model.SecurityIncident
import com.example.data.model.Teacher
import com.example.ui.components.SchoolCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    schools: List<School>,
    teachers: List<Teacher>,
    incidents: List<SecurityIncident>,
    adminName: String,
    onAddSchool: (School) -> Unit,
    onUpdateSchool: (School) -> Unit,
    onDeleteSchool: (School) -> Unit,
    onSchoolClick: (Long) -> Unit,
    onNavigateToTeachers: () -> Unit,
    onNavigateToIncidents: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToExcelImport: () -> Unit,
    onNavigateToAddIncident: () -> Unit,
    onNavigateToSettings: () -> Unit,
    leaves: List<com.example.data.model.TeacherLeaveEntity> = emptyList(),
    penalties: List<com.example.data.model.TeacherPenaltyEntity> = emptyList(),
    trips: List<com.example.data.model.SchoolTripEntity> = emptyList()
) {
    // Stage Filter State (Dropdown Menu)
    var selectedStageFilter by remember { mutableStateOf<SchoolStage?>(null) }
    var isStageMenuExpanded by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    // Dialog State for Add / Edit School
    var showAddSchoolDialog by remember { mutableStateOf(false) }
    var schoolToEdit by remember { mutableStateOf<School?>(null) }
    var showAiAssistantDialog by remember { mutableStateOf(false) }

    // Filtered Schools calculation
    val filteredSchools = remember(schools, selectedStageFilter, searchQuery) {
        schools.filter { school ->
            val matchesStage = selectedStageFilter == null || school.stage == selectedStageFilter
            val matchesQuery = searchQuery.isBlank() ||
                    school.name.contains(searchQuery, ignoreCase = true) ||
                    school.principalName.contains(searchQuery, ignoreCase = true) ||
                    school.address.contains(searchQuery, ignoreCase = true) ||
                    school.securityOfficerName.contains(searchQuery, ignoreCase = true)
            matchesStage && matchesQuery
        }
    }

    // Totals for top statistics
    val totalCameras = remember(schools) { schools.sumOf { it.camerasCount } }
    val totalExtinguishers = remember(schools) { schools.sumOf { it.extinguishersCount } }
    val inProgressIncidentsCount = remember(incidents) { incidents.count { it.status == IncidentStatus.IN_PROGRESS } }

    // Dialog display
    if (showAddSchoolDialog || schoolToEdit != null) {
        AddEditSchoolDialog(
            schoolToEdit = schoolToEdit,
            onDismiss = {
                showAddSchoolDialog = false
                schoolToEdit = null
            },
            onSaveSchool = { savedSchool ->
                if (savedSchool.id > 0) {
                    onUpdateSchool(savedSchool)
                } else {
                    onAddSchool(savedSchool)
                }
                showAddSchoolDialog = false
                schoolToEdit = null
            }
        )
    }

    // AI Assistant Dialog
    if (showAiAssistantDialog) {
        com.example.ui.components.SmartQueryAssistantDialog(
            schools = schools,
            teachers = teachers,
            incidents = incidents,
            leaves = leaves,
            penalties = penalties,
            trips = trips,
            onDismiss = { showAiAssistantDialog = false }
        )
    }

    Scaffold(
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // AI Assistant Floating Action Button
                ExtendedFloatingActionButton(
                    onClick = { showAiAssistantDialog = true },
                    containerColor = Color(0xFF6366F1),
                    contentColor = Color.White,
                    icon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFFFFD700)) },
                    text = { Text("المساعد الذكي (AI)", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("fab_ai_assistant")
                )

                // Add School Floating Action Button
                ExtendedFloatingActionButton(
                    onClick = {
                        schoolToEdit = null
                        showAddSchoolDialog = true
                    },
                    containerColor = EduGreen,
                    contentColor = Color.White,
                    icon = { Icon(Icons.Default.AddBusiness, contentDescription = null) },
                    text = { Text("إضافة مدرسة جديدة", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("fab_add_school")
                )
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            // Header Banner: اسم المحافظة والإدارة في الأعلى
            item {
                DashboardHeader(
                    adminName = adminName,
                    totalSchools = schools.size,
                    totalCameras = totalCameras,
                    totalExtinguishers = totalExtinguishers,
                    inProgressIncidents = inProgressIncidentsCount
                )
            }

            // Quick Access Tabs Bar (الوقائع، المعلمين، استيراد Excel، التقارير)
            item {
                QuickNavRow(
                    teachersCount = teachers.size,
                    incidentsCount = incidents.size,
                    onNavigateToIncidents = onNavigateToIncidents,
                    onNavigateToTeachers = onNavigateToTeachers,
                    onNavigateToExcelImport = onNavigateToExcelImport,
                    onNavigateToReports = onNavigateToReports
                )
            }

            // Section Header & Single Dropdown Menu for School Stage Filtering
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FilterList, contentDescription = null, tint = EduBlue)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "تصفية المدارس حسب المرحلة التعليمية",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            if (selectedStageFilter != null || searchQuery.isNotBlank()) {
                                TextButton(
                                    onClick = {
                                        selectedStageFilter = null
                                        searchQuery = ""
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text("إعادة ضبط", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // ExposedDropdownMenuBox for School Stage Selection
                        ExposedDropdownMenuBox(
                            expanded = isStageMenuExpanded,
                            onExpandedChange = { isStageMenuExpanded = !isStageMenuExpanded },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = selectedStageFilter?.displayNameAr ?: "جميع المراحل التعليمية (الكل)",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("المرحلة التعليمية") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isStageMenuExpanded) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Category,
                                        contentDescription = null,
                                        tint = EduBlue
                                    )
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth()
                                    .testTag("dropdown_filter_stage")
                            )

                            ExposedDropdownMenu(
                                expanded = isStageMenuExpanded,
                                onDismissRequest = { isStageMenuExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = "جميع المراحل التعليمية (الكل - ${schools.size} مدرسة)",
                                            fontWeight = if (selectedStageFilter == null) FontWeight.Bold else FontWeight.Normal,
                                            color = if (selectedStageFilter == null) EduBlue else MaterialTheme.colorScheme.onSurface
                                        )
                                    },
                                    onClick = {
                                        selectedStageFilter = null
                                        isStageMenuExpanded = false
                                    }
                                )

                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                                SchoolStage.values().forEach { stage ->
                                    val countInStage = schools.count { it.stage == stage }
                                    DropdownMenuItem(
                                        text = {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = stage.displayNameAr,
                                                    fontWeight = if (selectedStageFilter == stage) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (selectedStageFilter == stage) EduBlue else MaterialTheme.colorScheme.onSurface
                                                )
                                                Surface(
                                                    color = EduBlue.copy(alpha = 0.1f),
                                                    shape = RoundedCornerShape(6.dp)
                                                ) {
                                                    Text(
                                                        text = "$countInStage مدرسة",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = EduBlue,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        },
                                        onClick = {
                                            selectedStageFilter = stage
                                            isStageMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Fast Search Field
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("بحث باسم المدرسة أو المدير أو مسؤول الأمن...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = EduBlue) },
                            trailingIcon = {
                                if (searchQuery.isNotBlank()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Close, contentDescription = "مسح")
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("search_schools_field")
                        )
                    }
                }
            }

            // Schools List Header Counter
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "المدارس المسجلة (${filteredSchools.size})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )

                    if (selectedStageFilter != null) {
                        Surface(
                            color = EduBlue.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "مرحلة: ${selectedStageFilter?.displayNameAr}",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = EduBlue,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Schools Cards List
            if (filteredSchools.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.School,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "لا توجد مدارس مطابقة للبحث أو الفلتر المحدد",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            FilledTonalButton(
                                onClick = {
                                    selectedStageFilter = null
                                    searchQuery = ""
                                }
                            ) {
                                Text("عرض جميع المدارس")
                            }
                        }
                    }
                }
            } else {
                items(filteredSchools, key = { it.id }) { school ->
                    Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                        SchoolCard(
                            school = school,
                            onSchoolClick = { onSchoolClick(school.id) },
                            onEditSchool = { schoolToEdit = school },
                            onDeleteSchool = { onDeleteSchool(school) }
                        )
                    }
                }
            }
        }
    }
}

/**
 * شريط العنوان والبيانات الرسمية بالأعلى (المحافظة والإدارة والمسؤول)
 */
@Composable
fun DashboardHeader(
    adminName: String,
    totalSchools: Int,
    totalCameras: Int,
    totalExtinguishers: Int,
    inProgressIncidents: Int
) {
    // هيدر مصغّر: سطر واحد للعنوان + سطر للإحصائيات (لتوفير مساحة للقائمة)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = EduBlueDark),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(EduBlueDark, EduBlue)
                    )
                )
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .background(EduGold, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = EduBlueDark,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "إدارة سمالوط التعليمية - قسم الأمن",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White,
                        maxLines = 1
                    )
                    Text(
                        text = "المسؤول: $adminName",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                        color = EduGold,
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                StatBadge(
                    count = totalSchools.toString(),
                    label = "المدارس",
                    icon = Icons.Default.School
                )
                StatBadge(
                    count = totalCameras.toString(),
                    label = "الكاميرات",
                    icon = Icons.Default.Videocam,
                    accentColor = EduGold
                )
                StatBadge(
                    count = totalExtinguishers.toString(),
                    label = "الطفايات",
                    icon = Icons.Default.FireExtinguisher
                )
                StatBadge(
                    count = inProgressIncidents.toString(),
                    label = "قيد المتابعة",
                    icon = Icons.Default.PendingActions,
                    accentColor = if (inProgressIncidents > 0) Color(0xFFFFB74D) else Color.White
                )
            }
        }
    }
}

/**
 * شارات الإحصائيات في الهيدر
 */
@Composable
fun StatBadge(
    count: String,
    label: String,
    icon: ImageVector,
    accentColor: Color = Color.White
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = count,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = accentColor
            )
        }
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = Color.White.copy(alpha = 0.85f)
        )
    }
}

/**
 * أزرار الوصول السريع للأقسام الهامة (الوقائع، المعلمين، استيراد Excel، التقارير)
 */
@Composable
fun QuickNavRow(
    teachersCount: Int,
    incidentsCount: Int,
    onNavigateToIncidents: () -> Unit,
    onNavigateToTeachers: () -> Unit,
    onNavigateToExcelImport: () -> Unit,
    onNavigateToReports: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        QuickNavChip(
            title = "الأحداث والوقائع",
            subtitle = "$incidentsCount واقعة",
            icon = Icons.Default.WarningAmber,
            accentColor = Color(0xFFD32F2F),
            modifier = Modifier.weight(1f),
            onClick = onNavigateToIncidents
        )

        QuickNavChip(
            title = "المعلمين والموظفين",
            subtitle = "$teachersCount كادر",
            icon = Icons.Default.Groups,
            accentColor = EduGreen,
            modifier = Modifier.weight(1f),
            onClick = onNavigateToTeachers
        )

        QuickNavChip(
            title = "استيراد Excel",
            subtitle = "XLSX / CSV",
            icon = Icons.Default.TableChart,
            accentColor = EduBlue,
            modifier = Modifier.weight(1f),
            onClick = onNavigateToExcelImport
        )

        QuickNavChip(
            title = "التقارير",
            subtitle = "PDF / طباعة",
            icon = Icons.Default.Assessment,
            accentColor = EduGoldDark,
            modifier = Modifier.weight(1f),
            onClick = onNavigateToReports
        )
    }
}

@Composable
fun QuickNavChip(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(accentColor.copy(alpha = 0.12f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}

@Composable
fun RecentIncidentItem(
    incident: SecurityIncident,
    onClick: () -> Unit
) {
    val statusColor = when (incident.status) {
        IncidentStatus.RESOLVED -> StatusResolved
        IncidentStatus.IN_PROGRESS -> StatusInProgress
        IncidentStatus.CLOSED -> StatusClosed
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(40.dp)
                    .background(statusColor, RoundedCornerShape(2.dp))
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = incident.title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1
                )
                Text(
                    text = "${incident.schoolName} • ${incident.dateString}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Surface(
                color = statusColor.copy(alpha = 0.12f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = incident.status.displayNameAr,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = statusColor,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
    }
}
