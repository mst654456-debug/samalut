package com.example.util

import com.example.data.model.IncidentStatus
import com.example.data.model.School
import com.example.data.model.SchoolTripEntity
import com.example.data.model.SecurityIncident
import com.example.data.model.Teacher
import com.example.data.model.TeacherLeaveEntity
import com.example.data.model.TeacherPenaltyEntity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * معالج استعلامات ذكي باللغة العربية يعتمد على تحليل النصوص والبيانات المحلية
 * (Natural Language Smart Query Engine for Samalut Education Security)
 */
object SmartQueryEngine {

    data class QueryResponse(
        val question: String,
        val title: String,
        val summary: String,
        val rawResultsCount: Int,
        val formattedDetails: String,
        val shareableText: String
    )

    fun processNaturalLanguageQuery(
        query: String,
        schools: List<School>,
        teachers: List<Teacher>,
        incidents: List<SecurityIncident>,
        leaves: List<TeacherLeaveEntity>,
        penalties: List<TeacherPenaltyEntity>,
        trips: List<SchoolTripEntity>
    ): QueryResponse {
        val q = query.trim().lowercase(Locale.getDefault())

        val calendar = Calendar.getInstance()
        val currentMonth = calendar.get(Calendar.MONTH) + 1 // 1-12
        val currentYear = calendar.get(Calendar.YEAR)

        // 1. الاستعلام عن الإجازات (من عنده إجازة؟ مين في إجازة الشهر ده؟)
        if (q.contains("إجاز") || q.contains("اجاز") || q.contains("مرضي") || q.contains("عارض") || q.contains("اعتياد")) {
            val matchingLeaves = leaves.filter { leave ->
                val schoolMatch = schools.find { s -> q.contains(s.name.lowercase()) || s.name.lowercase().contains(q) }
                val matchesSchool = schoolMatch == null || leave.schoolName.equals(schoolMatch.name, ignoreCase = true)
                matchesSchool
            }

            val builder = StringBuilder()
            if (matchingLeaves.isEmpty()) {
                val text = "لم يتم العثور على أي إجازات مسجلة تطابق استفسارك حالياً."
                return QueryResponse(
                    question = query,
                    title = "سجل الإجازات",
                    summary = text,
                    rawResultsCount = 0,
                    formattedDetails = text,
                    shareableText = "📋 استعلام أمن سمالوط:\n$text"
                )
            }

            builder.append("📊 بيان إجازات المعلمين والعاملين المسجلة (${matchingLeaves.size}):\n\n")
            matchingLeaves.forEachIndexed { idx, lv ->
                val activeStatus = if (lv.isCurrentlyActive) "🟢 سارية حالياً" else "⚪ منتهية/مجدولة"
                builder.append("${idx + 1}. ${lv.teacherName}\n")
                builder.append("   • المدرسة: ${lv.schoolName}\n")
                builder.append("   • نوع الإجازة: ${lv.leaveType} (${lv.daysCount} أيام)\n")
                builder.append("   • الفترة: من ${lv.startDate} إلى ${lv.endDate} ($activeStatus)\n")
                if (lv.destination.isNotBlank()) builder.append("   • الوجهة: ${lv.destination}\n")
                builder.append("\n")
            }

            val summary = "تم رصد ${matchingLeaves.size} إجازة مسجلة (${matchingLeaves.count { it.isCurrentlyActive }} سارية حالياً)."
            return QueryResponse(
                question = query,
                title = "تقرير إجازات المعلمين",
                summary = summary,
                rawResultsCount = matchingLeaves.size,
                formattedDetails = builder.toString(),
                shareableText = "📋 إدارة أمن سمالوط التعليمية - تقرير الإجازات:\n$summary\n\n${builder.toString()}"
            )
        }

        // 2. الاستعلام عن الرحلات والفعاليات
        if (q.contains("رحل") || q.contains("فعالي") || q.contains("نشاط") || q.contains("زيار") || q.contains("أتوبيس") || q.contains("اتوبيس")) {
            val matchedSchool = schools.find { s -> q.contains(s.name.lowercase()) }
            val matchingTrips = trips.filter { trip ->
                matchedSchool == null || trip.schoolName.equals(matchedSchool.name, ignoreCase = true) || trip.schoolId == matchedSchool.id
            }

            val builder = StringBuilder()
            if (matchingTrips.isEmpty()) {
                val schoolNotice = if (matchedSchool != null) "بمدرسة ${matchedSchool.name}" else "بجميع المدارس"
                val text = "لا توجد رحلات أو فعاليات مدرسية مسجلة $schoolNotice."
                return QueryResponse(
                    question = query,
                    title = "تقرير الرحلات والأنشطة",
                    summary = text,
                    rawResultsCount = 0,
                    formattedDetails = text,
                    shareableText = "🚌 استعلام أمن سمالوط:\n$text"
                )
            }

            builder.append("🚌 بيان الرحلات والأنشطة المدرسية (${matchingTrips.size}):\n\n")
            matchingTrips.forEachIndexed { idx, tr ->
                builder.append("${idx + 1}. وجهة الرحلة: ${tr.destination}\n")
                builder.append("   • المدرسة: ${tr.schoolName}\n")
                builder.append("   • التاريخ والموعد: ${tr.tripDate} (ساعة التجمع: ${tr.assemblyTime})\n")
                builder.append("   • عدد الطلاب: ${tr.studentsCount} طالب | حالة التأمين: ${tr.approvalStatus}\n")
                if (tr.supervisors.isNotEmpty()) {
                    builder.append("   • المشرفون: ${tr.supervisors.joinToString(", ")}\n")
                }
                if (tr.busNumber.isNotBlank() || tr.transportCompany.isNotBlank()) {
                    builder.append("   • الحافلة والنقل: ${tr.transportCompany} (${tr.busNumber})\n")
                }
                builder.append("\n")
            }

            val summary = "تم العثور على ${matchingTrips.size} رحلة/نشاط مدرسي مسجل."
            return QueryResponse(
                question = query,
                title = "بيان الرحلات المدرسية والتأمين",
                summary = summary,
                rawResultsCount = matchingTrips.size,
                formattedDetails = builder.toString(),
                shareableText = "🚌 إدارة أمن سمالوط التعليمية - بيان خط سير وتأمين الرحلات:\n$summary\n\n${builder.toString()}"
            )
        }

        // 3. الاستعلام عن الجزاءات والخصومات
        if (q.contains("جزاء") || q.contains("خصم") || q.contains("إنذار") || q.contains("انذار") || q.contains("لفت نظر") || q.contains("عقوب")) {
            val matchedSchool = schools.find { s -> q.contains(s.name.lowercase()) }
            val matchingPenalties = penalties.filter { p ->
                matchedSchool == null || p.schoolName.equals(matchedSchool.name, ignoreCase = true)
            }

            val builder = StringBuilder()
            if (matchingPenalties.isEmpty()) {
                val schoolNotice = if (matchedSchool != null) "في مدرسة ${matchedSchool.name}" else "في المدارس المحددة"
                val text = "سجل الجزاءات نظيف تماماً ولم يتم العثور على جزاءات مسجلة $schoolNotice."
                return QueryResponse(
                    question = query,
                    title = "تقرير الجزاءات والخصومات",
                    summary = text,
                    rawResultsCount = 0,
                    formattedDetails = text,
                    shareableText = "⚖️ استعلام أمن سمالوط:\n$text"
                )
            }

            builder.append("⚖️ بيان الجزاءات والخصومات المسجلة (${matchingPenalties.size}):\n\n")
            matchingPenalties.forEachIndexed { idx, p ->
                builder.append("${idx + 1}. ${p.teacherName}\n")
                builder.append("   • المدرسة: ${p.schoolName}\n")
                builder.append("   • نوع الجزاء: ${p.penaltyType} (${if (p.daysDeducted > 0) "${p.daysDeducted} أيام خصم" else "تنبيه إداري"})\n")
                builder.append("   • السبب: ${p.reason}\n")
                builder.append("   • التاريخ ورقم القرار: ${p.dateString} ${if (p.decisionNumber.isNotBlank()) "(قرار ${p.decisionNumber})" else ""}\n")
                builder.append("\n")
            }

            val summary = "تم رصد ${matchingPenalties.size} جزاء مسجل على مستوى المعلمين والعاملين."
            return QueryResponse(
                question = query,
                title = "تقرير الجزاءات والقرارات التأديبية",
                summary = summary,
                rawResultsCount = matchingPenalties.size,
                formattedDetails = builder.toString(),
                shareableText = "⚖️ إدارة أمن سمالوط التعليمية - تقرير الجزاءات:\n$summary\n\n${builder.toString()}"
            )
        }

        // 4. الاستعلام عن الوقائع والأحداث الجارية
        if (q.contains("واقع") || q.contains("حدث") || q.contains("احداث") || q.contains("أحداث") || q.contains("مشكل") || q.contains("أمن") || q.contains("امن")) {
            val matchedSchool = schools.find { s -> q.contains(s.name.lowercase()) }
            val onlyOngoing = q.contains("جاري") || q.contains("مفتوح") || q.contains("قيد المتابع")
            val matchingIncidents = incidents.filter { inc ->
                val schoolMatch = matchedSchool == null || inc.schoolName.equals(matchedSchool.name, ignoreCase = true)
                val statusMatch = if (onlyOngoing) inc.status == IncidentStatus.IN_PROGRESS else true
                schoolMatch && statusMatch
            }

            val builder = StringBuilder()
            if (matchingIncidents.isEmpty()) {
                val text = "سجل الأحداث نظيف ومستقر تماماً والحمد لله، ولا توجد أحداث مسجلة تطابق استعلامك."
                return QueryResponse(
                    question = query,
                    title = "تقرير الأحداث الأمنية",
                    summary = text,
                    rawResultsCount = 0,
                    formattedDetails = text,
                    shareableText = "🛡️ إفادة أمن سمالوط:\n$text"
                )
            }

            builder.append("🛡️ بيان الأحداث الأمنية (${matchingIncidents.size}):\n\n")
            matchingIncidents.forEachIndexed { idx, inc ->
                val statusAr = when (inc.status) {
                    IncidentStatus.IN_PROGRESS -> "⚠️ جاري المتابعة"
                    IncidentStatus.RESOLVED -> "✅ تم الحل"
                    IncidentStatus.CLOSED -> "🔒 مغلقة"
                }
                builder.append("${idx + 1}. [${inc.schoolName}] ${inc.title}\n")
                builder.append("   • الحالة: $statusAr | التاريخ: ${inc.dateString} (${inc.timeString})\n")
                builder.append("   • الوصف: ${inc.description}\n")
                if (inc.actionTaken.isNotBlank()) builder.append("   • الإجراء المتخذ: ${inc.actionTaken}\n")
                builder.append("\n")
            }

            val summary = "تم رصد ${matchingIncidents.size} حادثة مسجلة (${matchingIncidents.count { it.status == IncidentStatus.IN_PROGRESS }} جاري متابعتها)."
            return QueryResponse(
                question = query,
                title = "تقرير الأحداث الأمنية",
                summary = summary,
                rawResultsCount = matchingIncidents.size,
                formattedDetails = builder.toString(),
                shareableText = "🛡️ إدارة أمن سمالوط التعليمية - تقرير الأحداث:\n$summary\n\n${builder.toString()}"
            )
        }

        // 5. الاستعلام عن مدرسة بعينها أو تجهيزاتها (كاميرات، طفايات، مباني، مديرين)
        val matchedSchool = schools.find { s -> q.contains(s.name.lowercase()) }
        if (matchedSchool != null) {
            val builder = StringBuilder()
            builder.append("🏫 بطاقة وبيانات مدرسة: ${matchedSchool.name}\n\n")
            builder.append("• المرحلة التعليمية: ${matchedSchool.stage.displayNameAr}\n")
            builder.append("• كود المدرسة: ${matchedSchool.code.ifBlank { "غير مسجل" }}\n")
            builder.append("• مدير المدرسة: ${matchedSchool.principalName} (${matchedSchool.principalPhone})\n")
            builder.append("• مسؤول الأمن بالمدرسة: ${matchedSchool.securityOfficerName} (${matchedSchool.securityOfficerPhone})\n")
            if (matchedSchool.vicePrincipals.isNotEmpty()) {
                builder.append("• الوكلاء (${matchedSchool.vicePrincipals.size}): ${matchedSchool.vicePrincipals.joinToString { "${it.name} (${it.phone})" }}\n")
            }
            builder.append("• التجهيزات والأعداد:\n")
            builder.append("   - الفصول: ${matchedSchool.classroomsCount} | المعلمون: ${matchedSchool.teachersCount} | العمال: ${matchedSchool.workersCount}\n")
            builder.append("   - المباني: ${matchedSchool.buildingsCount} | طفايات الحريق: ${matchedSchool.extinguishersCount} | كاميرات المراقبة: ${matchedSchool.camerasCount}\n")
            if (matchedSchool.attachedFiles.isNotEmpty()) {
                builder.append("• المستندات والقرارات المرفقة: ${matchedSchool.attachedFiles.size} ملفات\n")
            }

            val schoolTeachersCount = teachers.count { it.schoolName == matchedSchool.name }
            val schoolIncidentsCount = incidents.count { it.schoolName == matchedSchool.name }
            val schoolTripsCount = trips.count { it.schoolName == matchedSchool.name }

            builder.append("\n📊 إحصائيات سريعة:\n")
            builder.append("• المعلمون المسجلون: $schoolTeachersCount\n")
            builder.append("• سجل الأحداث: $schoolIncidentsCount\n")
            builder.append("• الرحلات المسجلة: $schoolTripsCount\n")

            val summary = "بيانات مدرسة ${matchedSchool.name} وتجهيزاتها الأمنية والإدارية."
            return QueryResponse(
                question = query,
                title = matchedSchool.name,
                summary = summary,
                rawResultsCount = 1,
                formattedDetails = builder.toString(),
                shareableText = "🏫 إدارة أمن سمالوط - بطاقة مدرسة:\n\n${builder.toString()}"
            )
        }

        // 6. استعلام عام / افتراضي (بحث نصي عام في المدارس والمعلمين والوقائع)
        val matchingSchools = schools.filter { it.name.contains(q, ignoreCase = true) || it.principalName.contains(q, ignoreCase = true) }
        val matchingTeachers = teachers.filter { it.name.contains(q, ignoreCase = true) || it.teacherCode.contains(q, ignoreCase = true) }

        val builder = StringBuilder()
        builder.append("نتائج البحث الذكي عن: «$query»\n\n")

        if (matchingSchools.isNotEmpty()) {
            builder.append("🏫 المدارس المطابقة (${matchingSchools.size}):\n")
            matchingSchools.take(5).forEach { s ->
                builder.append("• ${s.name} - مديرها: ${s.principalName} (${s.principalPhone})\n")
            }
            builder.append("\n")
        }

        if (matchingTeachers.isNotEmpty()) {
            builder.append("👨‍🏫 المعلمون المطابقون (${matchingTeachers.size}):\n")
            matchingTeachers.take(5).forEach { t ->
                builder.append("• ${t.name} (${t.jobTitle}) - مدرسة: ${t.schoolName} - هاتف: ${t.phone}\n")
            }
            builder.append("\n")
        }

        val totalFound = matchingSchools.size + matchingTeachers.size
        val summary = if (totalFound > 0) {
            "تم العثور على $totalFound نتيجة مطابقة في قاعدة بيانات أمن سمالوط."
        } else {
            "لم يتم العثور على بيانات مباشرة مطابقة لكلمة البحث. يمكنك السؤال عن: الإجازات، الرحلات، الجزاءات، الأحداث، أو اسم مدرسة بعينها."
        }

        return QueryResponse(
            question = query,
            title = "المساعد الذكي لأمن سمالوط",
            summary = summary,
            rawResultsCount = totalFound,
            formattedDetails = if (totalFound > 0) builder.toString() else summary,
            shareableText = "🔍 استعلام أمن سمالوط التعليمية:\n$summary\n\n${if (totalFound > 0) builder.toString() else ""}"
        )
    }
}
